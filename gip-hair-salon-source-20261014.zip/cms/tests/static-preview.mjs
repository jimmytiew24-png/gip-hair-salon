import { spawn } from 'node:child_process';
import { once } from 'node:events';
import assert from 'node:assert/strict';
const child=spawn(process.execPath,['local-server.mjs'],{cwd:new URL('../../',import.meta.url),env:{...process.env,PORT:'3131'},stdio:['ignore','pipe','pipe']});
try {
  await Promise.race([once(child.stdout,'data'),once(child,'exit').then(()=>{throw new Error('Preview did not start');})]);
  for(const [path,status]of [['/',200],['/content.php',403],['/admin/api.php',403],['/admin/lib/seed.json',403],['/images/uploads/.htaccess',403]])assert.equal((await fetch('http://127.0.0.1:3131'+path)).status,status,path);
  console.log('Static launcher serves the website and denies PHP, admin source and dotfiles.');
}finally{child.kill();}
