<?php
declare(strict_types=1);
$root=(string)getenv('GIP_CMS_PUBLIC_ROOT');
$uri=rawurldecode(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH) ?: '/');
if (str_contains($uri,'..') || str_contains($uri,"\0") || preg_match('~(?:^|/)\.|^/admin/lib(?:/|$)|^/images/uploads/.*\.(?:php\d*|phtml|html|svg)$~i',$uri)) { http_response_code(403); exit('Forbidden'); }
$file=$root.$uri;
if (is_file($file)) return false;
if ($uri==='/admin' || $uri==='/admin/') { require $root.'/admin/index.php'; return true; }
if (is_file(rtrim($file,'/').'.html')) { header('Content-Type: text/html; charset=utf-8'); readfile(rtrim($file,'/').'.html'); return true; }
if (is_file(rtrim($file,'/').'/index.html')) { header('Content-Type: text/html; charset=utf-8'); readfile(rtrim($file,'/').'/index.html'); return true; }
http_response_code(404); exit('Not found');
