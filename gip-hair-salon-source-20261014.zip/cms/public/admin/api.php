<?php
declare(strict_types=1);
require __DIR__ . '/lib/core.php';
ini_set('display_errors', '0');
gip_headers(true);
try {
    gip_require_host(); gip_session();
    $action = $_GET['action'] ?? 'state';
    if (!is_string($action)) throw new GipError(400, '无效操作。');
    $store = gip_read();
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'state') {
        $state = gip_state($store, gip_user($store, false));
        $state['publicOrigin'] = gip_local() ? 'http://' . $_SERVER['HTTP_HOST'] : gip_deployment()['public_origin'];
        $state['environmentReady'] = extension_loaded('gd') && extension_loaded('fileinfo');
        gip_json($state);
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new GipError(405, '请使用正确的请求方式。');
    gip_csrf();
    $data = $action === 'upload' ? $_POST : gip_body();
    if (in_array($action, ['setup','accept_invite','login'], true)) {
        gip_rate($action);
        if ($action === 'login') {
            $username = strtolower(gip_text($data['username'] ?? '', 64));
            $candidate = null;
            foreach ($store['users'] as $entry) if ($entry['username'] === $username) $candidate = $entry;
            if (!$candidate || !$candidate['enabled'] || !is_string($data['password'] ?? null) || !password_verify($data['password'], $candidate['passwordHash'] ?? '')) {
                gip_rate($action, true); throw new GipError(401, '账号或密码不正确。');
            }
            gip_login($candidate); gip_rate($action, false, true);
            gip_json(gip_state($store,$candidate) + ['publicOrigin' => gip_local() ? 'http://' . $_SERVER['HTTP_HOST'] : gip_deployment()['public_origin']]);
        }
        $token = $data['token'] ?? '';
        if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/D', $token)) { gip_rate($action,true); throw new GipError(403, '邀请或启用链接无效。'); }
        $tokenHash = hash('sha256',$token);
        $hash = gip_password($data['password'] ?? '');
        $result = gip_mutate(function(array &$state) use ($data,$action,$tokenHash,$hash) {
            if ($action === 'setup') {
                $configured = gip_deployment()['setup_key_hash'];
                if (count($state['users']) || $configured === '' || !hash_equals($configured,$tokenHash)) { gip_rate($action,true); throw new GipError(403, '启用链接无效或已使用。'); }
                $username = strtolower(gip_text($data['username'] ?? '',64,true));
                if (!preg_match('/^[a-z0-9][a-z0-9_.-]{2,47}$/D',$username)) throw new GipError(422,'账号请用 3–48 位英文字母、数字或点号。');
                $id = 'u-' . bin2hex(random_bytes(8));
                $user = ['id'=>$id,'username'=>$username,'name'=>gip_text($data['name'] ?? '',120,true),'role'=>'admin','scope'=>GIP_ARTISTS,'enabled'=>true,'passwordHash'=>$hash,'sessionVersion'=>bin2hex(random_bytes(16)),'createdAt'=>gmdate('c'),'inviteHash'=>'','inviteExpires'=>0];
            } else {
                $user = null;
                foreach ($state['users'] as $entry) if ($entry['inviteHash'] !== '' && hash_equals($entry['inviteHash'],$tokenHash) && $entry['inviteExpires'] >= time()) $user = $entry;
                if (!$user) { gip_rate($action,true); throw new GipError(403,'邀请链接已失效，请联系管理员重新邀请。'); }
                $id = $user['id']; $user['passwordHash']=$hash; $user['enabled']=true; $user['sessionVersion']=bin2hex(random_bytes(16)); $user['inviteHash']=''; $user['inviteExpires']=0;
            }
            $state['users'][$id]=$user;
            gip_audit($state,$action,$id);
            return $id;
        });
        $user=$result['store']['users'][$result['result']];
        gip_login($user); gip_rate($action,false,true);
        gip_json(gip_state($result['store'],$user) + ['publicOrigin'=>gip_local() ? 'http://' . $_SERVER['HTTP_HOST'] : gip_deployment()['public_origin']]);
    }
    $user=gip_user($store);
    if ($action === 'logout') {
        $_SESSION=[]; session_destroy();
        setcookie(session_name(),'', ['expires'=>time()-3600,'path'=>'/','secure'=>!gip_local(),'httponly'=>true,'samesite'=>'Strict']);
        gip_json(['ok'=>true]);
    }
    $version=$data['version'] ?? null;
    if (is_string($version) && ctype_digit($version)) $version=(int)$version;
    if (!is_int($version)) throw new GipError(422,'缺少内容版本，请刷新页面。');
    $uploaded=null;
    if ($action === 'upload') {
        $owner=gip_text($data['owner'] ?? '',60,true); gip_scope($user,$owner);
        $uploaded=gip_upload();
    }
    try {
        $result=gip_mutate(function(array &$state) use ($data,$action,$uploaded) {
            $current=gip_user($state);
            if ($action === 'upload') {
                $owner=gip_text($data['owner'] ?? '',60,true); gip_scope($current,$owner);
                $mode=$data['mode'] ?? 'artwork';
                if ($mode === 'portrait') {
                    if (!in_array($owner,GIP_ARTISTS,true)) throw new GipError(422,'请选择发型师资料。');
                    foreach ($state['artists'] as &$artist) if ($artist['id'] === $owner) $artist['image']=$uploaded['image'];
                    unset($artist); gip_audit($state,'portrait',$owner); return null;
                }
                if ($mode !== 'artwork') throw new GipError(422,'无效上传类型。');
                $category=gip_text($data['category'] ?? '',80,true);
                if (!isset(GIP_CATEGORIES[$category])) throw new GipError(422,'请选择作品分类。');
                $serviceList=json_decode($data['services'] ?? '[]',true);
                $serviceList=gip_list($serviceList,GIP_SERVICES);
                if (count($state['artworks'])>=3000) throw new GipError(422,'作品数量已达上限，请整理旧作品。');
                $id='photo-' . bin2hex(random_bytes(8));
                $featured=$current['role']==='admin' && ($data['featured'] ?? '')==='1';
                $state['artworks'][]=['id'=>$id,'owner'=>$owner,'image'=>$uploaded['image'],'category'=>$category,'label'=>GIP_CATEGORIES[$category],'caption'=>['en'=>gip_text($data['captionEn'] ?? '',500),'zh'=>gip_text($data['captionZh'] ?? '',500)],'visible'=>($data['publish'] ?? '')==='1','deleted'=>false,'order'=>time(),'services'=>$serviceList,'featured'=>$featured,'createdAt'=>gmdate('c')];
                gip_audit($state,'upload',$id); return $id;
            }
            if ($action === 'save_artist') {
                $owner=gip_text($data['id'] ?? '',60,true); gip_scope($current,$owner);
                if (!in_array($owner,GIP_ARTISTS,true)) throw new GipError(422,'请选择发型师资料。');
                $name=gip_text($data['name'] ?? '',120,true);
                $handle=gip_text($data['handle'] ?? '',60);
                if ($handle !== '' && !preg_match('/^[A-Za-z0-9_.]{1,30}$/D',$handle)) throw new GipError(422,'Instagram 账号请不要包含 @ 或网址。');
                foreach ($state['artists'] as &$artist) if ($artist['id'] === $owner) {
                    $artist['name']=$name; $artist['role']=['en'=>gip_text($data['roleEn'] ?? '',180,true),'zh'=>gip_text($data['roleZh'] ?? '',180,true)];
                    $artist['handle']=$handle; $artist['instagram']=$handle!=='' ? 'https://www.instagram.com/' . $handle . '/' : '';
                    $artist['bio']=['en'=>gip_text($data['bioEn'] ?? '',1800),'zh'=>gip_text($data['bioZh'] ?? '',1800)];
                }
                unset($artist); gip_audit($state,$action,$owner); return null;
            }
            if (in_array($action,['save_item','trash','restore'],true)) {
                $id=gip_text($data['id'] ?? '',80,true); $found=false;
                foreach ($state['artworks'] as &$item) if ($item['id'] === $id) {
                    $found=true; gip_scope($current,$item['owner']);
                    if ($action === 'trash') { $item['deleted']=true; $item['visible']=false; }
                    elseif ($action === 'restore') { $item['deleted']=false; $item['visible']=false; }
                    else {
                        $owner=gip_text($data['owner'] ?? '',60,true); gip_scope($current,$owner);
                        $category=gip_text($data['category'] ?? '',80,true);
                        if (!isset(GIP_CATEGORIES[$category])) throw new GipError(422,'请选择有效分类。');
                        if (!is_bool($data['visible'] ?? null)) throw new GipError(422,'无效显示状态。');
                        if ($item['deleted']) throw new GipError(422,'请先从回收站恢复作品。');
                        $item['owner']=$owner; $item['category']=$category; $item['label']=GIP_CATEGORIES[$category];
                        $item['caption']=['en'=>gip_text($data['captionEn'] ?? '',500),'zh'=>gip_text($data['captionZh'] ?? '',500)];
                        $item['visible']=$data['visible']; $item['services']=gip_list($data['services'] ?? [],GIP_SERVICES);
                        if ($current['role']==='admin') {
                            if (!is_bool($data['featured'] ?? null)) throw new GipError(422,'无效精选状态。');
                            $item['featured']=$data['featured'];
                        }
                    }
                }
                unset($item); if (!$found) throw new GipError(404,'找不到这张作品。');
                gip_audit($state,$action,$id); return null;
            }
            if ($action === 'reorder') {
                $owner=gip_text($data['owner'] ?? '',60,true); gip_scope($current,$owner);
                $owned=array_values(array_filter($state['artworks'],static fn($x)=>$x['owner']===$owner && !$x['deleted']));
                $ids=gip_list($data['ids'] ?? [],array_column($owned,'id'));
                if (count($ids)!==count($owned)) throw new GipError(422,'作品顺序不完整，请清除筛选后重试。');
                $ranks=array_flip($ids);
                foreach ($state['artworks'] as &$item) if ($item['owner']===$owner && !$item['deleted']) $item['order']=$ranks[$item['id']];
                unset($item); gip_audit($state,$action,$owner); return null;
            }
            if ($action === 'invite_user') {
                gip_admin($current);
                if (count($state['users'])>=30) throw new GipError(422,'员工账号已达上限。');
                $username=strtolower(gip_text($data['username'] ?? '',64,true));
                if (!preg_match('/^[a-z0-9][a-z0-9_.-]{2,47}$/D',$username)) throw new GipError(422,'账号请用 3–48 位英文字母、数字或点号。');
                foreach ($state['users'] as $entry) if ($entry['username']===$username) throw new GipError(422,'这个账号已存在。');
                $role=$data['role'] ?? '';
                if (!in_array($role,['admin','editor'],true)) throw new GipError(422,'请选择正确权限。');
                $scope=$role==='admin' ? GIP_ARTISTS : gip_list($data['scope'] ?? [],GIP_ARTISTS);
                if (!$scope) throw new GipError(422,'请为员工分配至少一位发型师。');
                $id='u-' . bin2hex(random_bytes(8)); $token=bin2hex(random_bytes(32));
                $state['users'][$id]=['id'=>$id,'username'=>$username,'name'=>gip_text($data['name'] ?? '',120,true),'role'=>$role,'scope'=>$scope,'enabled'=>false,'passwordHash'=>'','sessionVersion'=>bin2hex(random_bytes(16)),'createdAt'=>gmdate('c'),'inviteHash'=>hash('sha256',$token),'inviteExpires'=>time()+172800];
                gip_audit($state,$action,$id); return ['inviteToken'=>$token,'username'=>$username];
            }
            if (in_array($action,['save_user','renew_invite'],true)) {
                gip_admin($current); $id=gip_text($data['id'] ?? '',80,true);
                if (!isset($state['users'][$id])) throw new GipError(404,'找不到这个账号。');
                if ($id===$current['id']) throw new GipError(422,'不能通过这里更改自己的权限或停用自己。');
                $target=&$state['users'][$id];
                if ($action === 'renew_invite') {
                    if ($target['passwordHash']!=='') throw new GipError(422,'此账号已经启用，请由员工在账户设置更改密码。');
                    $token=bin2hex(random_bytes(32)); $target['inviteHash']=hash('sha256',$token); $target['inviteExpires']=time()+172800;
                    gip_audit($state,$action,$id); return ['inviteToken'=>$token,'username'=>$target['username']];
                }
                if (!in_array($data['role'] ?? '',['admin','editor'],true) || !is_bool($data['enabled'] ?? null)) throw new GipError(422,'账号权限格式不正确。');
                $target['role']=$data['role']; $target['scope']=$data['role']==='admin' ? GIP_ARTISTS : gip_list($data['scope'] ?? [],GIP_ARTISTS);
                if (!$target['scope']) throw new GipError(422,'请为员工分配发型师。');
                $target['enabled']=$data['enabled']; $target['sessionVersion']=bin2hex(random_bytes(16));
                if (!$target['enabled']) { $target['inviteHash']=''; $target['inviteExpires']=0; }
                gip_audit($state,$action,$id); return null;
            }
            if ($action === 'password') {
                if (!is_string($data['currentPassword'] ?? null) || !password_verify($data['currentPassword'],$current['passwordHash'])) throw new GipError(422,'当前密码不正确。');
                $state['users'][$current['id']]['passwordHash']=gip_password($data['password'] ?? '');
                $state['users'][$current['id']]['sessionVersion']=bin2hex(random_bytes(16));
                gip_audit($state,$action,$current['id']); return null;
            }
            throw new GipError(400,'无效操作。');
        },$version);
    } catch (Throwable $error) {
        if ($uploaded && is_file($uploaded['path'])) unlink($uploaded['path']);
        throw $error;
    }
    $store=$result['store'];
    if ($action==='password') gip_login($store['users'][$user['id']]);
    $fresh=gip_user($store);
    $response=gip_state($store,$fresh);
    $response['publicOrigin']=gip_local() ? 'http://' . $_SERVER['HTTP_HOST'] : gip_deployment()['public_origin'];
    if (is_array($result['result'])) $response += $result['result'];
    gip_json($response);
} catch (GipError $error) { gip_json(['error'=>$error->getMessage()],$error->status); }
catch (Throwable $error) { error_log('GIP CMS: ' . $error->getMessage()); gip_json(['error'=>'暂时无法保存，请稍后重试。若持续发生，请联系管理员。'],503); }
