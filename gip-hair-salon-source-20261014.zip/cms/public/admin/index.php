<?php
declare(strict_types=1);
require __DIR__ . '/lib/core.php';
gip_headers();
try { gip_require_host(); }
catch (GipError $error) { http_response_code($error->status); exit(htmlspecialchars($error->getMessage(),ENT_QUOTES,'UTF-8')); }
?><!doctype html>
<html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>GIP Studio · 内容管理</title><link rel="stylesheet" href="./studio.css?v=1"><link rel="icon" href="https://giphairsalon.com/images/gip-logo-en.png"></head>
<body><div id="app" aria-live="polite"><main class="boot"><p class="eyebrow">GIP STUDIO</p><h1>正在打开工作室…</h1></main></div><div id="toast" role="status" aria-live="polite"></div><script type="module" src="./studio.js?v=1"></script></body></html>
