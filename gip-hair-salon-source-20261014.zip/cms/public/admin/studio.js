const app = document.querySelector('#app');
const serviceNames = { cut:'剪发', colour:'染发', perm:'烫发', treatment:'头皮护理', extensions:'接发' };
let state = null, page = 'works', ownerFilter = 'all', statusFilter = 'all', categoryFilter = 'all', query = '';
let activationMode = '', activationToken = '';
const fragment = new URLSearchParams(location.hash.slice(1));
if (fragment.has('setup') || fragment.has('invite')) {
  activationMode = fragment.has('setup') ? 'setup' : 'invite';
  activationToken = fragment.get(activationMode) || '';
  history.replaceState(null,'',location.pathname);
}

function el(tag, attributes = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key,value] of Object.entries(attributes)) {
    if (value == null || value === false) continue;
    if (key.startsWith('on')) node.addEventListener(key.slice(2).toLowerCase(), value);
    else if (key === 'class') node.className = value;
    else if (key in node && !key.startsWith('aria-') && key !== 'role') node[key] = value;
    else node.setAttribute(key,String(value));
  }
  for (const child of children.flat(Infinity)) if (child != null && child !== false) node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  return node;
}
const button = (label, action, className = 'button', extra = {}) => el('button',{type:'button',class:className,onClick:action,...extra},label);
const field = (label,input,hint='') => el('label',{class:'field'},el('span',{},label),input,hint && el('small',{},hint));
const input = (name,value='',extra={}) => el('input',{name,value,...extra});
const textArea = (name,value='',maxLength=500) => el('textarea',{name,value,rows:3,maxLength});
const select = (name,options,value) => { const node=el('select',{name},options.map(([id,label])=>el('option',{value:id},label))); node.value=value; return node; };
const ownerName = id => id==='gip' ? 'GIP 品牌精选' : state.artists.find(x=>x.id===id)?.name || id;
const artistOptions = () => [...state.artists.map(x=>[x.id,x.name]), ...(state.user.role==='admin' ? [['gip','GIP 品牌精选']] : [])];
const categoryOptions = () => Object.entries(state.categories).map(([id,labels])=>[id,labels.zh]);
const checkbox = (name,label,checked=false) => el('label',{class:'check'},el('input',{type:'checkbox',name,checked}),el('span',{},label));
const imageUrl = image => `${state.publicOrigin}/images/${image.split('/').map(encodeURIComponent).join('/')}`;
function toast(message,error=false) { const box=document.querySelector('#toast'); box.textContent=message; box.className=error ? 'visible error' : 'visible'; clearTimeout(toast.timer); toast.timer=setTimeout(()=>box.className='',5000); }
async function request(action,data={},multipart=false) {
  const response = await fetch(`./api.php?action=${encodeURIComponent(action)}`, { method:'POST',credentials:'same-origin',headers:{'X-CSRF-Token':state.csrf,...(multipart ? {} : {'Content-Type':'application/json'})},body:multipart ? data : JSON.stringify({...data,version:state.version}) });
  const json = await response.json().catch(()=>({error:'连接失败，请稍后重试。'}));
  if (!response.ok) { const error=new Error(json.error || '操作未完成。'); error.status=response.status; throw error; }
  return json;
}
async function refresh() { const response=await fetch('./api.php?action=state',{cache:'no-store',credentials:'same-origin'}); const json=await response.json(); if (!response.ok) throw new Error(json.error || '无法连接后台。'); state=json; render(); }
async function mutate(action,data,success='已保存，官网会显示最新内容。') {
  try { state=await request(action,data); render(); toast(success); }
  catch(error) { if(error.status===401) { await refresh(); } toast(error.message,true); }
}
function formSubmit(form,handler) {
  form.addEventListener('submit',async event=>{
    event.preventDefault(); const submit=form.querySelector('button[type=submit]');
    if(submit.disabled) return; const previous=submit.textContent; submit.disabled=true; submit.textContent='正在保存…';
    try { await handler(new FormData(form)); }
    catch(error) { toast(error.message,true); if(error.status===401) { closeModal(); await refresh(); } }
    finally { submit.disabled=false; submit.textContent=previous; }
  });
}
let activeModal=null;
function closeModal() { if(activeModal) { activeModal.close(); activeModal.remove(); activeModal=null; } }
function modal(title,content) {
  closeModal(); const close=button('×',closeModal,'icon-button',{'aria-label':'关闭窗口'});
  const dialog=el('dialog',{class:'modal','aria-labelledby':'modal-title'},el('div',{class:'modal-heading'},el('div',{},el('p',{class:'eyebrow'},'GIP STUDIO'),el('h2',{id:'modal-title'},title)),close),content);
  document.body.append(dialog); activeModal=dialog; dialog.addEventListener('close',()=>{dialog.remove(); if(activeModal===dialog) activeModal=null;}); dialog.showModal(); return dialog;
}
function authView() {
  const settingUp = activationToken && (activationMode==='invite' || !state.configured);
  const waiting = !state.configured && !settingUp;
  const title = waiting ? '工作室，准备就绪。' : settingUp ? (activationMode==='setup' ? '创建管理员账号。' : '欢迎加入 GIP。') : '回到你的工作室。';
  const card=el('section',{class:'auth-card'},el('p',{class:'eyebrow'},'GIP CONTENT STUDIO'),el('h1',{},title),el('p',{class:'muted'},waiting ? '请使用专属启用链接，设置第一位管理员。' : settingUp ? '设置你自己的密码，开始管理网站内容。' : '登录后，管理作品、发型师资料与团队账号。'));
  if(waiting) card.append(el('p',{class:'notice'},'后台尚未启用。启用链接由网站管理员保管，没有预设密码。'));
  else {
    const form=el('form',{class:'auth-form'});
    if(!settingUp || activationMode==='setup') form.append(field('登录账号',input('username','',{required:true,autoComplete:'username',pattern:'[a-zA-Z0-9][a-zA-Z0-9_.-]{2,47}',maxLength:48}), '使用英文字母、数字或点号。'));
    if(settingUp && activationMode==='setup') form.append(field('你的称呼',input('name','',{required:true,maxLength:40,autoComplete:'name'})));
    form.append(field(settingUp ? '设置密码' : '密码',input('password','',{type:'password',required:true,minLength:settingUp ? 12 : 1,maxLength:72,autoComplete:settingUp ? 'new-password' : 'current-password'}),settingUp ? '至少 12 位，建议使用独立密码。' : ''));
    if(settingUp) form.append(field('再次输入密码',input('confirm','',{type:'password',required:true,minLength:12,maxLength:72,autoComplete:'new-password'})));
    form.append(el('button',{type:'submit',class:'button primary'},settingUp ? '设置密码并进入' : '登录工作室'));
    formSubmit(form,async values=>{
      if(settingUp && values.get('password')!==values.get('confirm')) throw new Error('两次输入的密码不一致。');
      state=await request(settingUp ? (activationMode==='setup' ? 'setup' : 'accept_invite') : 'login',{username:values.get('username') || '',name:values.get('name') || '',password:values.get('password'),token:activationToken});
      activationToken=''; activationMode=''; render();
    });
    card.append(form);
  }
  card.append(el('a',{class:'text-link',href:'https://giphairsalon.com',target:'_blank',rel:'noreferrer'},'查看 GIP 官网 ↗'));
  const branding = el('aside',{class:'auth-brand'},
    el('div',{class:'brand-text'},'GIP',el('small',{},'hair salon')),
    el('div',{},el('span',{class:'eyebrow'},'YOUR WORK, YOUR WAY.'),el('p',{},'让每一次更新，',el('br'),el('em',{},'都更简单。'))));
  return el('main',{class:'auth'},branding,card);
}
function render() {
  if(!state?.user) { app.replaceChildren(authView()); return; }
  const navItems=[['works','作品管理','▧'],['artists','发型师资料','◯'],...(state.user.role==='admin' ? [['users','团队账号','◇'],['audit','操作记录','↺']] : []),['account','我的账户','⚙']];
  if(!navItems.some(([id])=>id===page)) page='works';
  const side=el('aside',{class:'sidebar'},el('a',{class:'brand-text',href:'#',onClick:event=>{event.preventDefault(); page='works'; render();}},'GIP',el('small',{},'CONTENT STUDIO')),
    el('nav',{'aria-label':'后台导航'},navItems.map(([id,label,icon])=>button([el('span',{'aria-hidden':'true'},icon),label],()=>{page=id; render();},`nav-item${page===id?' selected':''}`,{'aria-current':page===id?'page':null}))),
    el('div',{class:'sidebar-bottom'},el('a',{href:state.publicOrigin,target:'_blank',rel:'noreferrer'},'查看官网 ↗'),el('p',{},state.user.name,el('small',{},state.user.role==='admin'?'管理员':'员工')),button('退出登录',async()=>{try{await request('logout'); await refresh();}catch(error){toast(error.message,true);}},'quiet')));
  const view={works:worksView,artists:artistsView,users:usersView,audit:auditView,account:accountView}[page]();
  const mobile=el('header',{class:'mobile-header'},el('strong',{},'GIP STUDIO'),select('page',navItems.map(([id,label])=>[id,label]),page));
  mobile.querySelector('select').setAttribute('aria-label','后台页面');
  mobile.querySelector('select').addEventListener('change',event=>{page=event.target.value;render();});
  app.replaceChildren(el('div',{class:'studio'},side,el('div',{class:'workspace'},mobile,view)));
}
function heading(kicker,title,description,actions=[]) { return el('header',{class:'page-heading'},el('div',{},el('p',{class:'eyebrow'},kicker),el('h1',{},title),el('p',{class:'muted'},description)),el('div',{class:'heading-actions'},actions)); }
function sorted(items) { return [...items].sort((a,b)=>a.order-b.order || a.id.localeCompare(b.id)); }
function worksView() {
  const items=state.artworks;
  const published=items.filter(x=>x.visible&&!x.deleted).length;
  const view=el('main',{class:'page'},heading('01 / YOUR WORK','每一份作品，都值得被看见。','选择作品归属和分类，保存后即可更新官网。',[button('＋ 上传照片',uploadDialog,'button primary',{disabled:!state.uploadReady})]),
    el('div',{class:'stats'},[['已发布',published],['草稿',items.filter(x=>!x.visible&&!x.deleted).length],['回收站',items.filter(x=>x.deleted).length]].map(([name,count])=>el('div',{},el('span',{},name),el('strong',{},count)))));
  if(!state.uploadReady) view.append(el('p',{class:'notice'},'主机图片处理扩展尚未开启，暂时无法上传。现有作品仍可编辑。'));
  const owners=select('owner',[['all','全部作品归属'],...artistOptions()],ownerFilter);
  const statuses=select('status',[['all','全部在用作品'],['published','已发布'],['draft','草稿'],['trash','回收站']],statusFilter);
  const categories=select('category',[['all','全部分类'],...categoryOptions()],categoryFilter);
  const search=input('search',query,{type:'search',placeholder:'搜索作品说明或发型师','aria-label':'搜索作品'});
  const filters=el('div',{class:'filters'},field('作品归属',owners),field('状态',statuses),field('分类',categories),field('搜索',search));
  const container=el('div',{class:'work-grid'}), summary=el('p',{class:'list-summary'});
  function renderCards(){
    const filtered=sorted(items).filter(x=>(ownerFilter==='all'||x.owner===ownerFilter)&&(categoryFilter==='all'||x.category===categoryFilter)&&(statusFilter==='trash'?x.deleted:!x.deleted)&&(statusFilter!=='published'||x.visible)&&(statusFilter!=='draft'||!x.visible)&&(`${ownerName(x.owner)} ${x.caption.zh} ${x.caption.en} ${x.label.zh}`.toLowerCase().includes(query.toLowerCase())));
    const canMove=ownerFilter!=='all'&&statusFilter==='all'&&categoryFilter==='all'&&!query;
    summary.textContent=`${filtered.length} 张作品${canMove?' · 使用箭头调整显示顺序':' · 选择具体作品归属并清除筛选，可调整顺序'}`;
    container.replaceChildren(...filtered.map(item=>workCard(item,canMove,filtered)));
    if(!filtered.length) container.append(el('div',{class:'empty'},el('h2',{},'这里还没有作品。'),el('p',{},statusFilter==='trash'?'删除的作品会出现在这里，可随时恢复。':'换个筛选条件，或上传第一张照片。')));
  }
  owners.addEventListener('change',()=>{ownerFilter=owners.value;renderCards();}); statuses.addEventListener('change',()=>{statusFilter=statuses.value;renderCards();}); categories.addEventListener('change',()=>{categoryFilter=categories.value;renderCards();}); search.addEventListener('input',()=>{query=search.value;renderCards();});
  renderCards(); view.append(filters,summary,container); return view;
}
function itemPayload(item,patch={}) { return {id:item.id,owner:item.owner,category:item.category,captionEn:item.caption.en,captionZh:item.caption.zh,visible:item.visible,featured:item.featured,services:item.services,...patch}; }
function workCard(item,canMove,list) {
  const status=item.deleted?'已删除':item.visible?'已发布':'草稿';
  const actions=item.deleted ? [button('恢复为草稿',()=>mutate('restore',{id:item.id},'已恢复为草稿，可编辑后再发布。'),'button small')] : [button('编辑',()=>editWork(item),'button small'),button(item.visible?'隐藏':'发布',()=>mutate('save_item',itemPayload(item,{visible:!item.visible})),'quiet small'),button('移入回收站',()=>confirmTrash(item),'quiet small danger')];
  if(canMove&&!item.deleted) for(const [offset,label] of [[-1,'向前'],[1,'向后']]) actions.push(button(offset===-1?'↑':'↓',()=>{const ids=list.map(x=>x.id), index=ids.indexOf(item.id), other=index+offset; if(other<0||other>=ids.length)return; [ids[index],ids[other]]=[ids[other],ids[index]]; mutate('reorder',{owner:item.owner,ids},'作品顺序已更新。');},'icon-button small',{'aria-label':`${label}移动 ${item.caption.zh||item.id}`,disabled:list.indexOf(item)+offset<0||list.indexOf(item)+offset>=list.length}));
  return el('article',{class:'work-card'},el('button',{class:'photo-button',type:'button',onClick:()=>editWork(item),'aria-label':`编辑 ${ownerName(item.owner)} 作品 ${item.id}`},el('img',{src:imageUrl(item.image),alt:item.caption.zh||`${ownerName(item.owner)} · ${item.label.zh}`,loading:'lazy'}),el('span',{class:`badge ${item.visible&&!item.deleted?'published':''}`},status)),el('div',{class:'card-body'},el('div',{class:'card-meta'},el('span',{},ownerName(item.owner)),el('span',{},item.label.zh)),el('h2',{},item.caption.zh||item.caption.en||'未填写作品说明'),el('p',{class:'card-placement'},[item.featured?'首页／作品页':'',...item.services.map(id=>serviceNames[id])].filter(Boolean).join(' · ')||'发型师个人作品页'),el('div',{class:'card-actions'},actions)));
}
function placementFields(item={}) { return el('fieldset',{class:'placements'},el('legend',{},'同时展示在服务项目'),Object.entries(serviceNames).map(([id,label])=>checkbox(`service-${id}`,label,item.services?.includes(id))),el('small',{},'每个服务项目最多展示顺序靠前的 6 张照片。')); }
function chosenServices(values) { return Object.keys(serviceNames).filter(id=>values.has(`service-${id}`)); }
function editWork(item) {
  const form=el('form',{},el('img',{class:'edit-preview',src:imageUrl(item.image),alt:'作品预览'}),el('div',{class:'form-grid'},field('归属',select('owner',artistOptions(),item.owner)),field('分类',select('category',categoryOptions(),item.category))),field('中文说明',textArea('captionZh',item.caption.zh,160)),field('English caption',textArea('captionEn',item.caption.en,350)),placementFields(item),checkbox('visible','发布到官网',item.visible));
  if(state.user.role==='admin') form.append(checkbox('featured','展示在首页与作品页',item.featured));
  form.append(el('div',{class:'modal-actions'},button('取消',closeModal,'button'),el('button',{type:'submit',class:'button primary',disabled:item.deleted},item.deleted?'请先恢复作品':'保存并发布')));
  formSubmit(form,async values=>{state=await request('save_item',{id:item.id,owner:values.get('owner'),category:values.get('category'),captionZh:values.get('captionZh'),captionEn:values.get('captionEn'),services:chosenServices(values),visible:values.has('visible'),featured:state.user.role==='admin'?values.has('featured'):item.featured});closeModal();render();toast('作品已保存。');});
  modal('编辑作品',form);
}
function confirmTrash(item) { modal('移入回收站？',el('div',{},el('p',{},'作品会从官网隐藏，并保留在回收站。你可以随时恢复。'),el('div',{class:'modal-actions'},button('保留作品',closeModal),button('移入回收站',async()=>{closeModal();await mutate('trash',{id:item.id},'作品已移入回收站。');},'button danger')))); }
async function optimizePhoto(file) {
  if(!['image/jpeg','image/png','image/webp'].includes(file.type)) throw new Error(`${file.name}：请使用 JPG、PNG 或 WebP。`);
  if(file.size>32*1024*1024)throw new Error(`${file.name}：文件太大，请先缩小。`);
  const bitmap=await createImageBitmap(file);
  try{
    const factor=Math.min(1,2400/Math.max(bitmap.width,bitmap.height));
    if(factor===1&&file.size<Math.min(1500000,state.maxUploadBytes)) return file;
    const canvas=document.createElement('canvas'); canvas.width=Math.max(32,Math.round(bitmap.width*factor));canvas.height=Math.max(32,Math.round(bitmap.height*factor));canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/webp',0.86));
    if(!blob||blob.size>state.maxUploadBytes)throw new Error(`${file.name}：压缩后仍太大，请缩小照片。`);
    return new File([blob],file.name.replace(/\.[^.]+$/,'')+'.webp',{type:'image/webp'});
  }finally{bitmap.close();}
}
function uploadDialog() {
  let files=[],urls=[];
  const picker=input('photos','',{type:'file',multiple:true,accept:'image/jpeg,image/png,image/webp',class:'file-input','aria-label':'选择要上传的照片'});
  const previews=el('div',{class:'upload-previews'}), feedback=el('p',{class:'muted',role:'status'},'可一次选择最多 20 张照片。大图会自动优化。');
  const drop=el('div',{class:'dropzone'},el('strong',{},'把照片拖到这里'),el('span',{},'或从电脑、手机中选择'),picker,button('选择照片',()=>picker.click()));
  function chosen(incoming){urls.forEach(URL.revokeObjectURL);files=[...incoming].slice(0,20);urls=files.map(file=>URL.createObjectURL(file));previews.replaceChildren(...files.map((file,index)=>el('div',{},el('img',{src:urls[index],alt:file.name}),el('small',{},file.name))));feedback.textContent=files.length?`已选择 ${files.length} 张照片`:'可一次选择最多 20 张照片。';}
  picker.addEventListener('change',()=>chosen(picker.files));
  drop.addEventListener('dragover',event=>{event.preventDefault();drop.classList.add('dragging');});drop.addEventListener('dragleave',()=>drop.classList.remove('dragging'));drop.addEventListener('drop',event=>{event.preventDefault();drop.classList.remove('dragging');chosen(event.dataTransfer.files);});
  const form=el('form',{},el('div',{class:'form-grid'},field('作品归属',select('owner',artistOptions(),ownerFilter==='all'?state.artists[0].id:ownerFilter)),field('作品分类',select('category',categoryOptions(),'Color'))),drop,previews,feedback,placementFields(),checkbox('publish','上传后发布到官网',true));
  if(state.user.role==='admin')form.append(checkbox('featured','同时展示在首页与作品页'));
  const progress=el('progress',{value:0,max:1,'aria-label':'上传进度'});form.append(progress,el('div',{class:'modal-actions'},button('取消',closeModal),el('button',{type:'submit',class:'button primary'},'开始上传')));
  const dialog=modal('上传新作品',form);
  dialog.addEventListener('close',()=>urls.forEach(URL.revokeObjectURL));
  formSubmit(form,async values=>{
    if(!files.length)throw new Error('请先选择照片。');
    const closeButtons=[dialog.querySelector('.modal-heading button'),form.querySelector('.modal-actions button[type=button]')]; closeButtons.forEach(node=>node.disabled=true);
    const preventClose=event=>event.preventDefault();dialog.addEventListener('cancel',preventClose);
    let success=0;const errors=[];progress.max=files.length;
    for(const [index,file] of files.entries()){
      feedback.textContent=`正在上传 ${index+1} / ${files.length}：${file.name}`;
      try{
        const photo=await optimizePhoto(file),data=new FormData();
        data.set('photo',photo);data.set('owner',values.get('owner'));data.set('category',values.get('category'));data.set('services',JSON.stringify(chosenServices(values)));data.set('publish',values.has('publish')?'1':'0');data.set('featured',values.has('featured')?'1':'0');data.set('version',state.version);
        state=await request('upload',data,true);success++;
      }catch(error){errors.push(`${file.name}：${error.message}`);if(error.status===401)break;}
      progress.value=index+1;
    }
    closeButtons.forEach(node=>node.disabled=false);dialog.removeEventListener('cancel',preventClose);
    if(errors.length){feedback.textContent=`成功 ${success} 张。${errors.join('；')}`;toast(`成功 ${success} 张，${errors.length} 张未完成。`,true);files=[];}
    else{closeModal();render();toast(`已上传 ${success} 张作品。`);}
  });
}
function artistsView(){return el('main',{class:'page'},heading('02 / THE PEOPLE','认识团队，也更新团队。','编辑名称、职务、简介、Instagram 账号与个人照片。'),el('div',{class:'artist-grid'},state.artists.map(person=>el('article',{class:'artist-card'},el('img',{src:imageUrl(person.image),alt:person.name,loading:'lazy'}),el('div',{},el('h2',{},person.name),el('p',{class:'muted'},person.role.zh),button('编辑资料',()=>editArtist(person),'button small'))))));}
function editArtist(person){
  const photo=input('portrait','',{type:'file',accept:'image/jpeg,image/png,image/webp'});
  const form=el('form',{},field('个人照片（可选更换）',photo),field('显示名称',input('name',person.name,{required:true,maxLength:40})),el('div',{class:'form-grid'},field('中文职务',input('roleZh',person.role.zh,{required:true,maxLength:60})),field('English role',input('roleEn',person.role.en,{required:true,maxLength:140}))),field('Instagram 账号',input('handle',person.handle,{maxLength:30,pattern:'[A-Za-z0-9_.]*'}),'只填写账号，不含 @。'),field('中文简介',textArea('bioZh',person.bio?.zh||'',550)),field('English biography',textArea('bioEn',person.bio?.en||'',1500)),el('div',{class:'modal-actions'},button('取消',closeModal),el('button',{type:'submit',class:'button primary'},'保存资料')));
  formSubmit(form,async values=>{
    if(photo.files.length){const data=new FormData();data.set('photo',await optimizePhoto(photo.files[0]));data.set('owner',person.id);data.set('mode','portrait');data.set('version',state.version);state=await request('upload',data,true);}
    state=await request('save_artist',{id:person.id,name:values.get('name'),roleEn:values.get('roleEn'),roleZh:values.get('roleZh'),handle:values.get('handle'),bioEn:values.get('bioEn'),bioZh:values.get('bioZh')});closeModal();render();toast('发型师资料已更新。');
  });modal(`编辑 ${person.name}`,form);
}
function usersView(){
  const rows=state.users.map(user=>el('article',{class:'user-row'},
    el('div',{class:'user-avatar'},user.name.slice(0,1)),
    el('div',{class:'user-info'},el('h2',{},user.name,user.id===state.user.id?'（你）':''),el('p',{},user.username,' · ',user.role==='admin'?'管理员':'员工'),el('small',{},user.role==='admin'?'全部内容':user.scope.map(ownerName).join('、'))),
    el('span',{class:`badge ${user.enabled?'published':''}`},user.enabled?'已启用':user.inviteExpires>0?'等待接受邀请':'已停用'),
    user.id!==state.user.id&&button('管理权限',()=>editUser(user),'button small'),
    user.inviteExpires>0&&button('重新生成邀请',async()=>{try{const result=await request('renew_invite',{id:user.id});state=result;render();showInvite(result);}catch(error){toast(error.message,true);}},'quiet small')));
  return el('main',{class:'page'},heading('03 / YOUR TEAM','让合适的人，管理合适的内容。','管理员可管理全部内容；员工只可编辑分配的发型师资料与作品。',[button('＋ 邀请员工',()=>editUser(),'button primary')]),el('div',{class:'user-list'},rows));
}
function scopeFields(user){return el('fieldset',{class:'placements'},el('legend',{},'员工可管理的发型师'),state.artists.map(person=>checkbox('scope-'+person.id,person.name,user?.scope.includes(person.id))),el('small',{},'管理员自动拥有全部权限。员工至少需要分配一位发型师。'));}
function editUser(user=null){
  const form=el('form',{},user?el('p',{class:'muted'},`账号：${user.username}`):el('div',{class:'form-grid'},field('登录账号',input('username','',{required:true,pattern:'[a-zA-Z0-9][a-zA-Z0-9_.-]{2,47}',maxLength:48})),field('员工称呼',input('name','',{required:true,maxLength:40}))),field('账号权限',select('role',[['editor','员工：仅管理分配内容'],['admin','管理员：全部内容与账号']],user?.role||'editor')),scopeFields(user));
  if(user)form.append(checkbox('enabled','允许登录',user.enabled));
  form.append(el('p',{class:'notice'},user?'更改权限或停用后，该员工需要重新登录。':'保存后生成 48 小时有效的邀请链接，由员工自行设置密码。'),el('div',{class:'modal-actions'},button('取消',closeModal),el('button',{type:'submit',class:'button primary'},user?'保存权限':'创建邀请')));
  formSubmit(form,async values=>{const payload={id:user?.id,username:values.get('username'),name:values.get('name'),role:values.get('role'),scope:state.artists.filter(x=>values.has('scope-'+x.id)).map(x=>x.id),enabled:values.has('enabled')};const result=await request(user?'save_user':'invite_user',payload);state=result;closeModal();render();if(user)toast('权限已保存。');else showInvite(result);});modal(user?'管理员工权限':'邀请新同事',form);
}
function showInvite(result){const link=new URL(location.href);link.hash='invite='+result.inviteToken;modal('邀请已准备好。',el('div',{},el('p',{},`账号 ${result.username} 的邀请链接将在 48 小时后失效，接受后立即失效。请私下交给对应同事。`),field('专属邀请链接',input('invite',link.href,{readOnly:true})),el('div',{class:'modal-actions'},button('关闭',closeModal),button('复制邀请链接',async()=>{try{await navigator.clipboard.writeText(link.href);toast('邀请链接已复制。');}catch{toast('请选中链接后复制。',true);}},'button primary'))));delete state.inviteToken;}
const auditNames={setup:'启用管理员',accept_invite:'接受邀请',upload:'上传作品',portrait:'更换个人照片',save_artist:'编辑发型师资料',save_item:'编辑作品',trash:'移入回收站',restore:'恢复作品',reorder:'调整顺序',invite_user:'邀请员工',save_user:'更新账号权限',renew_invite:'重新生成邀请',password:'更改密码'};
function auditView(){return el('main',{class:'page'},heading('04 / ACTIVITY','每次更新，都有迹可循。','显示最近的内容与账号操作。'),el('div',{class:'audit-list'},state.audit.map(entry=>el('article',{},el('time',{},new Date(entry.at).toLocaleString('zh-CN',{timeZone:'Asia/Kuala_Lumpur'})),el('strong',{},auditNames[entry.action]||entry.action),el('span',{},state.users.find(x=>x.id===entry.by)?.name||'首次设置'),el('small',{},entry.target)))));}
function accountView(){
  const form=el('form',{class:'account-form'},field('当前密码',input('currentPassword','',{type:'password',autoComplete:'current-password',required:true})),field('新密码',input('password','',{type:'password',autoComplete:'new-password',required:true,minLength:12,maxLength:72}),'至少 12 位。'),field('再次输入新密码',input('confirm','',{type:'password',autoComplete:'new-password',required:true,minLength:12,maxLength:72})),el('button',{class:'button primary',type:'submit'},'更新密码'));
  formSubmit(form,async values=>{if(values.get('password')!==values.get('confirm'))throw new Error('两次输入的密码不一致。');state=await request('password',{currentPassword:values.get('currentPassword'),password:values.get('password')});render();toast('密码已更改，其他登录会话已失效。');});
  return el('main',{class:'page'},heading('05 / YOUR ACCOUNT',state.user.name,'账号：'+state.user.username,[button('退出登录',async()=>{try{await request('logout');await refresh();}catch(error){toast(error.message,true);}})]),el('section',{class:'settings-card'},el('h2',{},'更改密码'),form));
}
refresh().catch(error=>app.replaceChildren(el('main',{class:'boot'},el('p',{class:'eyebrow'},'GIP STUDIO'),el('h1',{},'暂时无法打开工作室。'),el('p',{},error.message),button('重新连接',()=>location.reload(),'button primary'))));
