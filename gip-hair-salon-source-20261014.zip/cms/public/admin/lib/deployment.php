<?php
declare(strict_types=1);

// Deployment replaces only this random activation hash. No default password.
return [
    'setup_key_hash' => '',
    'admin_host' => 'admin.giphairsalon.com',
    'public_origin' => 'https://giphairsalon.com',
];
