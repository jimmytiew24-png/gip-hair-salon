<?php
declare(strict_types=1);

const GIP_ARTISTS = ['lim-wei-lun', 'kaa-yen', 'oscar', 'kay', 'junting', 'sky'];
const GIP_SERVICES = ['cut', 'colour', 'perm', 'treatment', 'extensions'];
const GIP_CATEGORIES = [
    'Color' => ['en' => 'Colour', 'zh' => '染发'],
    'Female Haircut' => ['en' => 'Women’s haircut', 'zh' => '女士剪发'],
    'Male Haircut' => ['en' => 'Men’s haircut', 'zh' => '男士剪发'],
    'Perm' => ['en' => 'Perm', 'zh' => '烫发'],
    'Hair Extension' => ['en' => 'Extensions', 'zh' => '接发'],
    'Make Up' => ['en' => 'Makeup', 'zh' => '化妆'],
    'Hairdo' => ['en' => 'Hairdo', 'zh' => '盘发'],
    'Scalp Treatment' => ['en' => 'Scalp care process', 'zh' => '头皮护理过程'],
    'Scalp Results' => ['en' => 'Scalp care results', 'zh' => '头皮护理效果'],
    'Reel stills' => ['en' => 'Hair styling · Reel cover', 'zh' => '发型作品 · 视频封面'],
    'soft' => ['en' => 'Soft tones', 'zh' => '柔和色调'],
    'statement' => ['en' => 'Statement colour', 'zh' => '鲜明色彩'],
    'contrast' => ['en' => 'Contrast', 'zh' => '层次对比'],
];

final class GipError extends RuntimeException {
    public function __construct(public int $status, string $message) { parent::__construct($message); }
}
function gip_deployment(): array { return require __DIR__ . '/deployment.php'; }
function gip_local(): bool {
    return PHP_SAPI === 'cli-server' && in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1'], true);
}
function gip_public_root(): string {
    return gip_local() && getenv('GIP_CMS_PUBLIC_ROOT') ? (string)getenv('GIP_CMS_PUBLIC_ROOT') : dirname(__DIR__, 2);
}
function gip_private_root(): string {
    return gip_local() && getenv('GIP_CMS_PRIVATE_ROOT') ? (string)getenv('GIP_CMS_PRIVATE_ROOT') : dirname(gip_public_root()) . '/gip-cms-private';
}
function gip_headers(bool $api = false): void {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header('X-Frame-Options: DENY');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header('Cache-Control: no-store, private');
    if (!gip_local()) header('Strict-Transport-Security: max-age=31536000');
    if ($api) header('Content-Type: application/json; charset=utf-8');
    else header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' https://giphairsalon.com data: blob:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
}
function gip_require_host(): void {
    $host = strtolower(explode(':', $_SERVER['HTTP_HOST'] ?? '')[0]);
    if (!gip_local() && $host !== gip_deployment()['admin_host']) throw new GipError(403, '请使用 admin.giphairsalon.com 进入后台。');
    if (!gip_local() && empty($_SERVER['HTTPS']) && ($_SERVER['SERVER_PORT'] ?? '') !== '443') throw new GipError(403, '请使用 HTTPS 安全连接。');
}
function gip_init(): void {
    $private = gip_private_root();
    if (!is_dir($private) && !mkdir($private, 0700, true) && !is_dir($private)) throw new RuntimeException('Private directory unavailable');
    foreach (['sessions', 'history'] as $name) if (!is_dir("$private/$name")) mkdir("$private/$name", 0700, true);
}
function gip_session(): void {
    gip_init();
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_maxlifetime', '1800');
    session_name('GIP_STUDIO');
    session_save_path(gip_private_root() . '/sessions');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => !gip_local(), 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
    if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
}
function gip_json(array $body, int $status = 200): never {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}
function gip_body(): array {
    if ((int)($_SERVER['CONTENT_LENGTH'] ?? 0) > 150000) throw new GipError(413, '请求过大。请分批保存。');
    try { $data = json_decode(file_get_contents('php://input'), true, 32, JSON_THROW_ON_ERROR); }
    catch (JsonException) { throw new GipError(400, '请求格式不正确。'); }
    if (!is_array($data) || array_is_list($data)) throw new GipError(400, '请求格式不正确。');
    return $data;
}
function gip_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) throw new GipError(403, '页面已过期，请刷新后重试。');
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $expected = (gip_local() ? 'http://' : 'https://') . ($_SERVER['HTTP_HOST'] ?? '');
    if ($origin !== '' && $origin !== $expected) throw new GipError(403, '请求来源不正确。');
}
function gip_text(mixed $value, int $max, bool $required = false): string {
    if (!is_string($value) || !preg_match('//u', $value)) throw new GipError(422, '文字格式不正确。');
    $value = trim($value);
    if (strlen($value) > $max || ($required && $value === '')) throw new GipError(422, '文字内容为空或太长。');
    return $value;
}
function gip_list(mixed $value, array $allowed): array {
    if (!is_array($value) || !array_is_list($value)) throw new GipError(422, '选择项目格式不正确。');
    foreach ($value as $item) if (!is_string($item) || !in_array($item, $allowed, true)) throw new GipError(422, '包含无效的选择项目。');
    return array_values(array_unique($value));
}
function gip_seed(): array { return json_decode(file_get_contents(__DIR__ . '/seed.json'), true, 64, JSON_THROW_ON_ERROR); }
function gip_read(): array {
    $path = gip_private_root() . '/store.json';
    return is_file($path) ? json_decode(file_get_contents($path), true, 64, JSON_THROW_ON_ERROR) : gip_seed();
}
function gip_atomic(string $path, array $data): void {
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    $temp = $path . '.' . bin2hex(random_bytes(8)) . '.tmp';
    try {
        if (file_put_contents($temp, $json, LOCK_EX) !== strlen($json)) throw new RuntimeException('Incomplete write');
        chmod($temp, 0600);
        if (!rename($temp, $path)) throw new RuntimeException('Atomic replacement failed');
    } finally { if (is_file($temp)) unlink($temp); }
}
function gip_mutate(callable $fn, ?int $version = null): array {
    gip_init();
    $lock = fopen(gip_private_root() . '/store.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX)) throw new RuntimeException('Cannot lock store');
    try {
        $store = gip_read();
        if ($version !== null && $version !== $store['version']) throw new GipError(409, '内容已被其他同事更新，请刷新后再保存。');
        $result = $fn($store);
        $store['version']++;
        $store['updatedAt'] = gmdate('c');
        $oldFile = gip_private_root() . '/store.json';
        if (is_file($oldFile)) {
            $history = gip_private_root() . '/history/' . $store['version'] . '.json';
            if (!copy($oldFile, $history)) throw new RuntimeException('Backup failed');
            chmod($history, 0600);
        }
        gip_atomic($oldFile, $store);
        $backups = glob(gip_private_root() . '/history/*.json') ?: [];
        usort($backups, static fn($a,$b) => (int)basename($b) <=> (int)basename($a));
        foreach (array_slice($backups, 30) as $old) unlink($old);
        return ['store' => $store, 'result' => $result];
    } finally { flock($lock, LOCK_UN); fclose($lock); }
}
function gip_audit(array &$store, string $action, string $target): void {
    $store['audit'][] = ['at' => gmdate('c'), 'by' => $_SESSION['user'] ?? 'setup', 'action' => $action, 'target' => $target];
    $store['audit'] = array_slice($store['audit'], -300);
}
function gip_user(array $store, bool $required = true): ?array {
    $id = $_SESSION['user'] ?? '';
    $user = $store['users'][$id] ?? null;
    $expired = time() - ($_SESSION['lastSeen'] ?? 0) > 1800 || time() - ($_SESSION['started'] ?? 0) > 43200;
    if (!$user || !$user['enabled'] || $expired || !hash_equals($user['sessionVersion'], $_SESSION['sessionVersion'] ?? '')) {
        unset($_SESSION['user'], $_SESSION['sessionVersion']);
        if ($required) throw new GipError(401, '请重新登录。');
        return null;
    }
    $_SESSION['lastSeen'] = time();
    return $user;
}
function gip_admin(array $user): void { if ($user['role'] !== 'admin') throw new GipError(403, '此操作需要管理员权限。'); }
function gip_scope(array $user, string $owner): void {
    if (!in_array($owner, [...GIP_ARTISTS,'gip'], true)) throw new GipError(422, '请选择有效的发型师。');
    if ($user['role'] !== 'admin' && !in_array($owner, $user['scope'], true)) throw new GipError(403, '你没有这位发型师的编辑权限。');
}
function gip_login(array $user): void {
    session_regenerate_id(true);
    $_SESSION = ['user' => $user['id'], 'sessionVersion' => $user['sessionVersion'], 'csrf' => bin2hex(random_bytes(32)), 'started' => time(), 'lastSeen' => time()];
}
function gip_password(mixed $password): string {
    if (!is_string($password) || !preg_match('//u', $password) || preg_match_all('/./us',$password)<12 || strlen($password)>72) throw new GipError(422, '请使用至少 12 位、长度适中的密码。');
    return password_hash($password, defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT);
}
function gip_rate(string $action, bool $failed = false, bool $clear = false): void {
    gip_init();
    $key = hash('sha256', $action . '|' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $file = gip_private_root() . '/rate-' . $key . '.json';
    $handle = fopen($file, 'c+');
    if (!$handle || !flock($handle, LOCK_EX)) throw new RuntimeException('Rate limit unavailable');
    try {
        $raw = stream_get_contents($handle);
        $record = $raw ? json_decode($raw, true) : null;
        if (!$record || $record['until'] < time()) $record = ['count' => 0, 'until' => time() + 900];
        if (!$clear && $record['count'] >= 8) throw new GipError(429, '尝试次数太多，请 15 分钟后再试。');
        if ($failed) $record['count']++;
        if ($clear) $record = ['count' => 0, 'until' => time() + 900];
        rewind($handle); ftruncate($handle, 0); fwrite($handle, json_encode($record));
        chmod($file, 0600);
    } finally { flock($handle, LOCK_UN); fclose($handle); }
}
function gip_public(array $store): array {
    $artists = $store['artists'];
    $portfolio = array_fill_keys(GIP_ARTISTS, []);
    $services = array_fill_keys(GIP_SERVICES, []); $showcase=[];
    $items = array_values(array_filter($store['artworks'], static fn($x) => $x['visible'] && !$x['deleted']));
    usort($items, static fn($a,$b) => ($a['order'] <=> $b['order']) ?: strcmp($a['id'],$b['id']));
    foreach ($items as $item) {
        $public = array_intersect_key($item, array_flip(['id','image','category','label','caption','post']));
        $public['owner'] = $item['owner'];
        $portfolio[$item['owner']][] = $public;
        if ($item['featured']) $showcase[]=$public;
        foreach ($item['services'] as $service) if (count($services[$service]) < 6) $services[$service][] = $public;
    }
    return ['schema' => 1, 'version' => $store['version'], 'updatedAt' => $store['updatedAt'], 'artists' => $artists, 'portfolio' => $portfolio, 'services' => $services, 'showcase'=>$showcase];
}
function gip_state(array $store, ?array $user): array {
    $response = ['configured' => count($store['users']) > 0, 'activationReady' => (gip_deployment()['setup_key_hash'] !== ''), 'csrf' => $_SESSION['csrf'], 'user' => null];
    if (!$user) return $response;
    $safeUser = array_intersect_key($user, array_flip(['id','username','name','role','scope']));
    $response['user'] = $safeUser;
    $response['version'] = $store['version'];
    $response['updatedAt'] = $store['updatedAt'];
    $response['artists'] = array_values(array_filter($store['artists'], static fn($person) => $user['role'] === 'admin' || in_array($person['id'], $user['scope'], true)));
    $response['artworks'] = array_values(array_filter($store['artworks'], static fn($item) => $user['role'] === 'admin' || in_array($item['owner'], $user['scope'], true)));
    $response['categories'] = GIP_CATEGORIES;
    $response['services'] = GIP_SERVICES;
    $response['uploadReady'] = extension_loaded('gd') && extension_loaded('fileinfo');
    $response['maxUploadBytes'] = min(8 * 1024 * 1024, gip_ini_bytes(ini_get('upload_max_filesize')), gip_ini_bytes(ini_get('post_max_size')) - 65536);
    if ($user['role'] === 'admin') {
        $response['users'] = array_map(static fn($entry) => array_intersect_key($entry, array_flip(['id','username','name','role','scope','enabled','createdAt','inviteExpires'])), array_values($store['users']));
        $response['audit'] = array_reverse(array_slice($store['audit'], -80));
    }
    return $response;
}
function gip_ini_bytes(string $value): int {
    if ((int)$value <= 0) return PHP_INT_MAX;
    $unit = strtolower(substr(trim($value), -1));
    return (int)$value * match($unit) { 'g' => 1073741824, 'm' => 1048576, 'k' => 1024, default => 1 };
}
function gip_image_path(string $image): string {
    if (!preg_match('~^(?:portfolio/[a-z0-9-]+/[a-z0-9-]+|team/[a-z0-9-]+|uploads/[a-f0-9]{32}|0[4-9]-artwork)\.(?:jpg|jpeg|png|webp)$~D', $image)) throw new GipError(422, '图片路径不正确。');
    return gip_public_root() . '/images/' . $image;
}
function gip_upload(): array {
    if (!extension_loaded('gd') || !extension_loaded('fileinfo')) throw new GipError(503, '主机图片扩展尚未开启，请联系管理员。');
    $file = $_FILES['photo'] ?? null;
    if (!$file || $file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) throw new GipError(422, '图片未上传成功，请检查大小后重试。');
    if ($file['size'] < 10 || $file['size'] > 8 * 1024 * 1024) throw new GipError(413, '每张照片请小于 8MB。');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!in_array($mime, ['image/jpeg','image/png','image/webp'], true)) throw new GipError(422, '只支持 JPG、PNG 和 WebP 照片。');
    $size = @getimagesize($file['tmp_name']);
    if (!$size || $size[0] < 32 || $size[1] < 32 || $size[0] > 12000 || $size[1] > 12000 || $size[0] * $size[1] > 24000000) throw new GipError(422, '图片尺寸不适合，请使用清晰、尺寸适中的照片。');
    $original = @imagecreatefromstring(file_get_contents($file['tmp_name']));
    if (!$original) throw new GipError(422, '无法读取这张照片。');
    if ($mime === 'image/jpeg' && function_exists('exif_read_data')) {
        $exif = @exif_read_data($file['tmp_name']);
        $orientation = $exif['Orientation'] ?? 1;
        if (in_array($orientation, [2,4,5,7], true)) imageflip($original, IMG_FLIP_HORIZONTAL);
        $angle = match($orientation) { 3,4 => 180, 5,6 => -90, 7,8 => 90, default => 0 };
        if ($angle) { $rotated = imagerotate($original, $angle, 0); imagedestroy($original); $original = $rotated; }
    }
    $width = imagesx($original); $height = imagesy($original);
    $ratio = min(1, 2400 / max($width,$height));
    $target = imagecreatetruecolor(max(1,(int)round($width*$ratio)), max(1,(int)round($height*$ratio)));
    imagealphablending($target, false); imagesavealpha($target, true);
    imagefill($target, 0, 0, imagecolorallocatealpha($target,255,255,255,127));
    imagecopyresampled($target, $original,0,0,0,0,imagesx($target),imagesy($target),$width,$height);
    imagedestroy($original);
    $extension = function_exists('imagewebp') ? 'webp' : ($mime === 'image/png' ? 'png' : 'jpg');
    $name = bin2hex(random_bytes(16)) . '.' . $extension;
    $folder = gip_public_root() . '/images/uploads';
    if (!is_dir($folder)) mkdir($folder, 0755, true);
    $path = "$folder/$name";
    $ok = match($extension) { 'webp' => imagewebp($target,$path,86), 'png' => imagepng($target,$path,7), default => imagejpeg($target,$path,88) };
    $dimensions = [imagesx($target), imagesy($target)];
    imagedestroy($target);
    if (!$ok) throw new RuntimeException('Cannot store image');
    chmod($path,0644);
    return ['image' => 'uploads/' . $name, 'path' => $path, 'width' => $dimensions[0], 'height' => $dimensions[1]];
}
