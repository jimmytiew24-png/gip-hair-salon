<?php
declare(strict_types=1);
ini_set('display_errors','0');
require __DIR__ . '/admin/lib/core.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-cache, must-revalidate');
try {
    if (!in_array($_SERVER['REQUEST_METHOD'],['GET','HEAD'],true)) { http_response_code(405); exit; }
    $body=json_encode(gip_public(gip_read()),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
    $etag='"' . hash('sha256',$body) . '"'; header('ETag: ' . $etag);
    if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '')===$etag) { http_response_code(304); exit; }
    if ($_SERVER['REQUEST_METHOD']==='GET') echo $body;
} catch (Throwable) { http_response_code(503); echo '{"error":"Content temporarily unavailable"}'; }
