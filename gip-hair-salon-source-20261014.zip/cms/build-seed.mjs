import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import ts from '../site/node_modules/typescript/lib/typescript.js';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const modules = join(root, '.runtime/seed-modules');
await mkdir(modules, { recursive: true });
for (const name of ['site', 'team']) {
  const source = await readFile(join(root, `site/content/${name}.ts`), 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 } }).outputText.replaceAll("'./site'", "'./site.mjs'");
  await writeFile(join(modules, name + '.mjs'), code);
}
const { team } = await import(pathToFileURL(join(modules, 'team.mjs')).href);
const { works } = await import(pathToFileURL(join(modules, 'site.mjs')).href);
const portfolio = JSON.parse(await readFile(join(root, 'site/content/portfolio.json'), 'utf8'));
const selected = {
  cut: portfolio['lim-wei-lun'].filter(x => x.category === 'Female Haircut').slice(0,3).map(x=>x.id),
  colour: portfolio.kay.slice(0,3).map(x=>x.id),
  perm: portfolio['kaa-yen'].filter(x => x.category === 'Perm').slice(0,3).map(x=>x.id),
  treatment: portfolio.sky.filter(x => x.category === 'Scalp Treatment').slice(0,3).map(x=>x.id),
  extensions: portfolio['kaa-yen'].filter(x => x.category === 'Hair Extension').slice(0,3).map(x=>x.id),
};
const artworks = Object.entries(portfolio).flatMap(([owner, items]) => items.map((x,index) => ({
  ...x, owner, caption: { en:'',zh:'' }, featured:false, visible:true, deleted:false, order:index,
  services: Object.entries(selected).filter(([,ids])=>ids.includes(x.id)).map(([id])=>id), createdAt:'2026-10-14T00:00:00Z',
})));
for (const [index, work] of works.entries()) artworks.push({
  id:work.id, owner:'gip', image:work.image, category:work.category, label:work.detail,
  caption:work.name, featured:true, visible:true, deleted:false, order:index, services:[], createdAt:'2026-10-14T00:00:00Z',
});
const seed = { schema:1, version:1, updatedAt:'2026-10-14T00:00:00Z', artists:team.map(({artwork,...x})=>({...x,bio:{en:'',zh:''}})), artworks, users:{}, audit:[] };
await writeFile(join(root,'cms/public/admin/lib/seed.json'),JSON.stringify(seed));
console.log(`Seed prepared: ${seed.artists.length} profiles, ${artworks.length} images, zero accounts.`);
