import { notFound } from 'next/navigation';
import { pages, nav, type Lang, type PageName } from '@/content/site';
import { SiteShell } from '@/components/gip/foundation';
import { Home } from '@/components/gip/home';
import {
  ServicesPage,
  WorkPage,
  SalonsPage,
} from '@/components/gip/experiences';
import { ConsultationPage } from '@/components/gip/consultation';
import { TeamPage } from '@/components/gip/team';
import { PortfolioPage } from '@/components/gip/portfolio';
import { team } from '@/content/team';
export const dynamicParams = false;
export function generateStaticParams() {
  return ['en', 'zh'].flatMap((lang) => [
    ...pages.map((page) => ({
      slug: [
        ...(lang === 'zh' ? ['zh'] : []),
        ...(page === 'home' ? [] : [page]),
      ],
    })),
    ...team.map((person) => ({
      slug: [...(lang === 'zh' ? ['zh'] : []), 'team', person.id],
    })),
  ]);
}
function route(slug: string[] = []) {
  const lang: Lang = slug[0] === 'zh' ? 'zh' : 'en';
  const rest = lang === 'zh' ? slug.slice(1) : slug;
  const page = (rest[0] || 'home') as PageName;
  const person =
    page === 'team' && rest.length === 2
      ? team.find((person) => person.id === rest[1])
      : undefined;
  if (
    rest.length > (person ? 2 : 1) ||
    !pages.includes(page) ||
    rest[0] === 'home'
  )
    notFound();
  return { lang, page, person };
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const { lang, page, person } = route((await params).slug);
  return {
    title: `${person ? person.name + (lang === 'en' ? ' · Selected work' : ' · 作品精选') : nav[lang][pages.indexOf(page)]} — GIP Hair Salon`,
    description:
      lang === 'en'
        ? 'Haircut, colour, texture and hair care. Explore GIP Hair Salon in Nilai and Kota Damansara.'
        : '探索 GIP 边缘设计的发型作品、服务与汝来和哥打白沙罗门店。',
    robots: { index: false, follow: false },
  };
}
export default async function Page({
  params,
}: {
  params: Promise<{ slug?: string[] }>;
}) {
  const { lang, page, person } = route((await params).slug);
  const Component = {
    home: Home,
    services: ServicesPage,
    work: WorkPage,
    salons: SalonsPage,
    team: TeamPage,
    visit: ConsultationPage,
  }[page];
  return (
    <SiteShell lang={lang} page={page} member={person?.id}>
      {person ? (
        <PortfolioPage lang={lang} person={person} />
      ) : (
        <Component lang={lang} />
      )}
    </SiteShell>
  );
}
