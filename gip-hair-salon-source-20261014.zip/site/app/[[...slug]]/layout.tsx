import '@/app/globals.css';
import '@/app/fonts.css';
export default async function RootLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ slug?: string[] }>;
}) {
  const { slug = [] } = await params;
  return (
    <html lang={slug[0] === 'zh' ? 'zh-CN' : 'en'}>
      <head>
        <link rel="icon" href="/images/gip-logo-en.png" type="image/png" />
      </head>
      <body>{children}</body>
    </html>
  );
}
