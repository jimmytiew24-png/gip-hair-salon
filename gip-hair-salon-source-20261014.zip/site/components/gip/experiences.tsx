'use client';
import { useEffect, useRef, useState } from 'react';
import {
  ArrowUpRight,
  ArrowLeft,
  ArrowRight,
  X,
  Plus,
  Phone,
  MapPin,
} from 'lucide-react';
import { animate, createScope } from 'animejs';
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import {
  type Lang,
  pick,
  pathFor,
  services,
  salons,
  hours,
} from '@/content/site';
import { SafeImage, TextLink, Closing } from './foundation';
import {
  serviceArtist,
  portfolioPath,
} from '@/content/artwork';
import { useServiceArtworks, useShowcaseWorks, useTeamMembers } from './managed-content';
import { ArtworkGallery } from './artwork-gallery';

export function PageIntro({
  lang,
  number,
  kicker,
  title,
  accent,
  description,
}: {
  lang: Lang;
  number: string;
  kicker: string;
  title: string;
  accent: string;
  description: string;
}) {
  return (
    <section className="page-intro wrap">
      <div className="page-kicker" data-enter>
        <span>
          {number} / {kicker}
        </span>
        <a href={pathFor(lang)}>GIP HAIR SALON</a>
      </div>
      <div className="page-intro-grid">
        <h1 data-enter>
          {title}
          <br />
          <em>{accent}</em>
        </h1>
        <p data-enter>{description}</p>
      </div>
    </section>
  );
}
export function ServicesPage({ lang }: { lang: Lang }) {
  const team = useTeamMembers();
  const serviceArtworks = useServiceArtworks();
  const servicePortfolio = (id: keyof typeof serviceArtist) => {
    const photo = serviceArtworks[id][0];
    const person = team.find(member => member.id === (photo?.owner || serviceArtist[id]));
    return person ? portfolioPath(lang, person) + '#' + encodeURIComponent(photo?.category || '') : pathFor(lang, 'work');
  };
  const serviceImageText = (index: number, language: Lang) => {
    const service = services[index], photo = serviceArtworks[service.id][0];
    const person = team.find(member => member.id === (photo?.owner || serviceArtist[service.id]));
    return photo ? `${photo.label[language]} · ${person?.name || 'GIP'}` : service.name[language];
  };
  const [active, setActive] = useState<string[]>(['cut']);
  const activeIndex = Math.max(
    0,
    services.findIndex((s) => s.id === active[0]),
  );
  const stage = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const chooseHash = () => {
      const id = location.hash.slice(1);
      if (services.some((s) => s.id === id)) setActive([id]);
    };
    // oxlint-disable-next-line react/react-compiler -- Synchronize the initial browser hash and later hashchange events.
    chooseHash();
    window.addEventListener('hashchange', chooseHash);
    return () => window.removeEventListener('hashchange', chooseHash);
  }, []);
  useEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const scope = createScope({ root: stage }).add(() => {
      animate('.safe-image', {
        opacity: [0.3, 1],
        duration: 280,
        ease: 'out(2)',
      });
    });
    return () => scope.revert();
  }, [activeIndex]);
  return (
    <>
      <PageIntro
        lang={lang}
        number="02"
        kicker={pick(lang, 'THE SERVICE INDEX', '服务目录')}
        title={pick(lang, 'Considered hair.', '认真对待，')}
        accent={pick(lang, 'Every detail.', '每一缕发丝。')}
        description={pick(
          lang,
          'A shape that feels right. A colour you’ve been thinking about. Let’s find your starting point.',
          '合适的轮廓，心动已久的色彩。从你最在意的细节，开始讨论。',
        )}
      />
      <section className="service-explorer wrap">
        <div>
          <Accordion
            value={active}
            onValueChange={(value) => setActive(value as string[])}
            className="service-accordion"
          >
            {services.map((s, i) => (
              <AccordionItem value={s.id} key={s.id} id={s.id}>
                <AccordionTrigger className="service-trigger">
                  <span className="index-label">0{i + 1}</span>
                  <span className="service-name">
                    {s.name[lang]}
                    <small>{s.subtitle[lang]}</small>
                  </span>
                </AccordionTrigger>
                <AccordionContent className="service-content">
                  <p>{s.description[lang]}</p>
                  <TextLink href={pathFor(lang, 'visit') + '?service=' + s.id}>
                    {pick(lang, 'Let’s talk about it', '聊聊这个项目')}
                  </TextLink>
                  <div className="service-results">
                    <h3>
                      {pick(
                        lang,
                        s.id === 'treatment'
                          ? 'Scalp care at GIP'
                          : 'A few finished looks',
                        s.id === 'treatment'
                          ? 'GIP 头皮护理实拍'
                          : '项目成品精选',
                      )}
                    </h3>
                    <ArtworkGallery
                      items={serviceArtworks[s.id]}
                      owner={
                        team.find(
                          (person) => person.id === (serviceArtworks[s.id][0]?.owner || serviceArtist[s.id]),
                        )?.name || 'GIP'
                      }
                      lang={lang}
                      filters={false}
                      compact
                    />
                    <TextLink
                      href={servicePortfolio(s.id)}
                    >
                      {pick(
                        lang,
                        'Explore the stylist’s work',
                        '查看发型师更多作品',
                      )}
                    </TextLink>
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <p className="service-note">
            {pick(
              lang,
              'Every head of hair is different. Your stylist will confirm options and pricing during your consultation.',
              '每个人的发质不同，具体方案与价格由发型师在咨询时确认。',
            )}
          </p>
        </div>
        <div ref={stage} className="service-stage">
          {serviceArtworks[services[activeIndex].id][0] ? <SafeImage
            src={serviceArtworks[services[activeIndex].id][0].image}
            alt={serviceImageText(activeIndex, lang)}
            lang={lang}
            eager
          /> : <p className="artwork-empty">{pick(lang, 'New work is on its way.', '作品即将更新。')}</p>}
          <div className="service-stage-caption">
            <span>
              0{activeIndex + 1} / {services[activeIndex].subtitle[lang]}
            </span>
            <span>{serviceImageText(activeIndex, lang)}</span>
          </div>
        </div>
      </section>
      <noscript>
        <section className="wrap no-script">
          {services.map((s) => (
            <div key={s.id}>
              <h2>{s.name[lang]}</h2>
              <p>{s.description[lang]}</p>
            </div>
          ))}
        </section>
      </noscript>
      <Closing lang={lang} />
    </>
  );
}
export function WorkPage({ lang }: { lang: Lang }) {
  const { works, filters } = useShowcaseWorks();
  const [filter, setFilter] = useState('all');
  const [selected, setSelected] = useState<string | null>(null);
  const opener = useRef<HTMLButtonElement | null>(null);
  const shown = works.filter((w) => filter === 'all' || w.category === filter);
  const current = shown.find((w) => w.id === selected);
  const index = shown.findIndex((w) => w.id === selected);
  const grid = useRef<HTMLDivElement>(null);
  const next = (delta: number) => {
    if (shown.length)
      setSelected(shown[(index + delta + shown.length) % shown.length].id);
  };
  useEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const scope = createScope({ root: grid }).add(() => {
      animate('.work-tile', {
        opacity: [0.35, 1],
        translateY: [10, 0],
        duration: 300,
        ease: 'out(2)',
      });
    });
    return () => scope.revert();
  }, [filter]);
  return (
    <>
      <PageIntro
        lang={lang}
        number="03"
        kicker={pick(lang, 'THE LOOKBOOK', '发型灵感册')}
        title={pick(lang, 'A point of view.', '发型，')}
        accent={pick(lang, 'Yours.', '自有态度。')}
        description={pick(
          lang,
          'Soft tones, bold changes, and the details in between. A selection of hair by GIP.',
          '柔和的色调、鲜明的改变，还有每一处细节。来看看 GIP 的发型作品。',
        )}
      />
      <section className="work-gallery wrap">
        <div className="filter-rail">
          <fieldset aria-label={pick(lang, 'Filter work', '筛选作品')}>
            {filters.map((f) => (
              <Button
                key={f.id}
                variant="ghost"
                className="filter-button"
                aria-pressed={filter === f.id}
                onClick={() => setFilter(f.id)}
              >
                {f.name[lang]}
                <sup>
                  {f.id === 'all'
                    ? works.length
                    : works.filter((w) => w.category === f.id).length}
                </sup>
              </Button>
            ))}
          </fieldset>
          <span className="filter-count" aria-live="polite">
            {shown.length} {pick(lang, 'LOOKS', '款发型')}
          </span>
        </div>
        <div className="contact-sheet" ref={grid}>
          {shown.map((w, i) => (
            <article className="work-tile" id={'look-' + w.id} key={w.id}>
              <button
                className="work-open"
                onClick={(e) => {
                  opener.current = e.currentTarget;
                  setSelected(w.id);
                }}
                aria-label={pick(lang, 'Open ' + w.name.en, '查看' + w.name.zh)}
              >
                <SafeImage
                  src={w.image}
                  alt={w.name[lang]}
                  lang={lang}
                  eager={i < 2}
                />
                <span className="work-open-icon">
                  <Plus size={22} />
                </span>
              </button>
              <div className="gallery-caption">
                <span className="index-label">
                  {String(works.indexOf(w) + 1).padStart(2, '0')}
                </span>
                <div>
                  <h2>{w.name[lang]}</h2>
                  <p>{w.detail[lang]}</p>
                </div>
                <ArrowUpRight size={20} />
              </div>
            </article>
          ))}
        </div>
        <div className="work-follow">
          <p>
            {pick(
              lang,
              'Found a look you love? Bring it to your consultation.',
              '找到喜欢的发型了吗？咨询时，带上它一起聊聊。',
            )}
          </p>
          <TextLink href="https://www.instagram.com/gip.hairsalon/">
            {pick(lang, 'More on Instagram', '在 Instagram 看更多')}
          </TextLink>
        </div>
      </section>
      <Dialog
        open={!!current}
        onOpenChange={(open) => {
          if (!open) setSelected(null);
        }}
      >
        <DialogContent
          className="work-lightbox"
          showCloseButton={false}
          finalFocus={opener}
          onKeyDown={(e) => {
            if (e.key === 'ArrowRight') {
              e.preventDefault();
              next(1);
            }
            if (e.key === 'ArrowLeft') {
              e.preventDefault();
              next(-1);
            }
          }}
        >
          {current && (
            <>
              <div className="lightbox-top">
                <span>
                  {String(index + 1).padStart(2, '0')} /{' '}
                  {String(shown.length).padStart(2, '0')}
                </span>
                <DialogClose
                  render={
                    <Button
                      className="icon-button"
                      variant="ghost"
                      aria-label={pick(lang, 'Close image', '关闭图片')}
                    />
                  }
                >
                  <X />
                </DialogClose>
              </div>
              <SafeImage
                src={current.image}
                alt={current.name[lang]}
                lang={lang}
                eager
              />
              <div className="lightbox-bottom">
                <Button
                  className="icon-button"
                  variant="outline"
                  aria-label={pick(lang, 'Previous image', '上一张图片')}
                  onClick={() => next(-1)}
                >
                  <ArrowLeft />
                </Button>
                <div>
                  <DialogTitle>{current.name[lang]}</DialogTitle>
                  <DialogDescription>{current.detail[lang]}</DialogDescription>
                </div>
                <Button
                  className="icon-button"
                  variant="outline"
                  aria-label={pick(lang, 'Next image', '下一张图片')}
                  onClick={() => next(1)}
                >
                  <ArrowRight />
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      <Closing lang={lang} />
    </>
  );
}
export function SalonsPage({ lang }: { lang: Lang }) {
  const [branch, setBranch] = useState('kd');
  return (
    <>
      <PageIntro
        lang={lang}
        number="04"
        kicker={pick(lang, 'FIND YOUR GIP', '找到你的 GIP')}
        title={pick(lang, 'Two spaces.', '两种空间，')}
        accent={pick(lang, 'One GIP.', '同一个 GIP。')}
        description={pick(
          lang,
          'A place to settle in, exchange ideas, and leave feeling a little more yourself.',
          '坐下来，聊聊想法。离开时，带着更自在的自己。',
        )}
      />
      <section className="salon-section wrap">
        <Tabs
          value={branch}
          onValueChange={(value) => setBranch(String(value))}
        >
          <TabsList className="salon-tabs">
            {salons.map((s, i) => (
              <TabsTrigger key={s.id} value={s.id}>
                <span className="index-label">0{i + 1}</span>
                {s.name[lang]}
                <ArrowUpRight size={20} />
              </TabsTrigger>
            ))}
          </TabsList>
          {salons.map((s, i) => (
            <TabsContent key={s.id} value={s.id}>
              <div className="salon-room">
                <div className="salon-photo">
                  <SafeImage
                    src={s.image}
                    alt={s.alt[lang]}
                    lang={lang}
                    eager
                  />
                  <span className="photo-corner">
                    0{i + 1} / GIP {s.name.en.toUpperCase()}
                  </span>
                </div>
                <div className="salon-details">
                  <span className="eyebrow">
                    {pick(lang, 'COME FIND US', '来这里，找到我们')}
                  </span>
                  <h2>{s.name[lang]}</h2>
                  <p className="salon-description">{s.description[lang]}</p>
                  <div className="salon-address">
                    <MapPin size={20} />
                    <address>{s.address}</address>
                  </div>
                  <p className="salon-hours">{hours[lang]}</p>
                  <div className="salon-actions">
                    <a href={`tel:+${s.phone}`}>
                      <Phone size={18} />
                      {s.displayPhone}
                    </a>
                    <a
                      href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent('GIP Hair Salon ' + s.address)}`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {pick(lang, 'Open in Maps', '查看地图')}
                      <ArrowUpRight size={18} />
                    </a>
                  </div>
                  <a
                    className="button-link"
                    href={pathFor(lang, 'visit') + '?salon=' + s.id}
                  >
                    {pick(lang, 'Consult with this salon', '向这家门店咨询')}
                    <ArrowUpRight size={19} />
                  </a>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
        <noscript>
          <div className="no-script">
            {salons.map((s) => (
              <div key={s.id}>
                <h2>{s.name[lang]}</h2>
                <p>{s.address}</p>
                <a href={'tel:+' + s.phone}>{s.displayPhone}</a>
              </div>
            ))}
          </div>
        </noscript>
      </section>
      <Closing lang={lang} />
    </>
  );
}
