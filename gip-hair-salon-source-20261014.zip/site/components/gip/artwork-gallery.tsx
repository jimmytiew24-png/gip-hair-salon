'use client';
import { useEffect, useRef, useState } from 'react';
import { ArrowLeft, ArrowRight, Plus, X } from 'lucide-react';
import { type Lang, pick } from '@/content/site';
import { SafeImage } from './foundation';
import { useTeamMembers } from './managed-content';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from '@/components/ui/dialog';

export type Artwork = {
  id: string;
  image: string;
  category: string;
  label: { en: string; zh: string };
  post?: string;
  owner?: string;
  caption?: { en: string; zh: string };
};
export function ArtworkGallery({
  items,
  lang,
  owner,
  filters = true,
  compact = false,
}: {
  items: Artwork[];
  lang: Lang;
  owner: string;
  filters?: boolean;
  compact?: boolean;
}) {
  const people = useTeamMembers();
  const ownerOf = (item: Artwork) => item.owner === 'gip' ? 'GIP' : people.find(person => person.id === item.owner)?.name || owner;
  const [category, setCategory] = useState('all');
  const [selected, setSelected] = useState<string | null>(null);
  const opener = useRef<HTMLButtonElement | null>(null);
  const categories = [...new Set(items.map((item) => item.category))];
  const shown = items.filter(
    (item) => category === 'all' || !categories.includes(category) || item.category === category,
  );
  const index = shown.findIndex((item) => item.id === selected);
  const current = shown[index];
  useEffect(() => {
    if (!filters) return;
    const fromHash = () => {
      let value = '';
      try {
        value = decodeURIComponent(location.hash.slice(1));
      } catch {
        return;
      }
      if (value && items.some((item) => item.category === value))
        setCategory(value);
    };
    // oxlint-disable-next-line react/react-compiler -- Synchronize shareable category hashes with browser navigation.
    fromHash();
    window.addEventListener('hashchange', fromHash);
    return () => window.removeEventListener('hashchange', fromHash);
  }, [items, filters]);
  const next = (delta: number) =>
    setSelected(shown[(index + delta + shown.length) % shown.length].id);
  return (
    <div
      className={`artwork-gallery${compact ? ' artwork-gallery-compact' : ''}`}
    >
      {filters && (
        <div className="artwork-filter-row">
          <fieldset
            className="team-filters"
            aria-label={pick(lang, 'Filter artwork', '筛选作品')}
          >
            <button
              type="button"
              aria-pressed={category === 'all'}
              onClick={() => {
                setCategory('all');
                setSelected(null);
              }}
            >
              {pick(lang, 'All work', '全部作品')}
            </button>
            {categories.map((value) => (
              <button
                key={value}
                type="button"
                aria-pressed={category === value}
                onClick={() => {
                  setCategory(value);
                  setSelected(null);
                }}
              >
                {items.find((item) => item.category === value)!.label[lang]}
              </button>
            ))}
          </fieldset>
          <span aria-live="polite">
            {shown.length} {pick(lang, 'images', '张作品')}
          </span>
        </div>
      )}
      <div className="artwork-grid">
        {shown.map((item, i) => (
          <article className="artwork-tile" key={item.id}>
            <button
              className="artwork-open"
              type="button"
              aria-label={`${pick(lang, 'Open', '查看')} ${ownerOf(item)} · ${item.label[lang]} · ${i + 1}`}
              onClick={(event) => {
                opener.current = event.currentTarget;
                setSelected(item.id);
              }}
            >
              <SafeImage
                src={item.image}
                alt={item.caption?.[lang] || `${ownerOf(item)} · ${item.label[lang]} · ${i + 1}`}
                lang={lang}
                eager={i < 3 && !compact}
              />
              <span className="artwork-open-cue" aria-hidden="true">
                <Plus size={22} />
              </span>
            </button>
            <div className="artwork-caption">
              <span>{item.caption?.[lang] || item.label[lang]}</span>
              <span>{String(i + 1).padStart(2, '0')}</span>
            </div>
          </article>
        ))}
      </div>
      {!items.length && <p className="artwork-empty">{pick(lang, 'New work is on its way. Contact the salon for ideas.', '作品即将更新，欢迎联系门店咨询。')}</p>}
      <Dialog
        open={!!current}
        onOpenChange={(open) => {
          if (!open) setSelected(null);
        }}
      >
        <DialogContent
          className="work-lightbox artwork-lightbox"
          showCloseButton={false}
          finalFocus={opener}
          onKeyDown={(event) => {
            if (event.key === 'ArrowRight') {
              event.preventDefault();
              next(1);
            }
            if (event.key === 'ArrowLeft') {
              event.preventDefault();
              next(-1);
            }
          }}
        >
          {current && (
            <>
              <div className="lightbox-top">
                <span>
                  {String(index + 1).padStart(2, '0')} /{' '}
                  {String(shown.length).padStart(2, '0')}
                </span>
                <DialogClose
                  render={
                    <Button
                      className="icon-button"
                      variant="ghost"
                      aria-label={pick(lang, 'Close image', '关闭图片')}
                    />
                  }
                >
                  <X />
                </DialogClose>
              </div>
              <SafeImage
                src={current.image}
                alt={`${ownerOf(current)} · ${current.label[lang]}`}
                lang={lang}
                eager
              />
              <div className="lightbox-bottom">
                <Button
                  className="icon-button"
                  variant="outline"
                  aria-label={pick(lang, 'Previous image', '上一张图片')}
                  onClick={() => next(-1)}
                >
                  <ArrowLeft />
                </Button>
                <div>
                  <DialogTitle>
                    {ownerOf(current)} · {current.label[lang]}
                  </DialogTitle>
                  <DialogDescription>
                    {current.caption?.[lang] || pick(lang, 'Selected work by GIP.', 'GIP 作品精选。')}
                  </DialogDescription>
                  {current.post && (
                    <a
                      className="artwork-original"
                      href={current.post}
                      target="_blank"
                      rel="noreferrer"
                    >
                      {pick(lang, 'Watch the original Reel', '观看原视频')} ↗
                    </a>
                  )}
                </div>
                <Button
                  className="icon-button"
                  variant="outline"
                  aria-label={pick(lang, 'Next image', '下一张图片')}
                  onClick={() => next(1)}
                >
                  <ArrowRight />
                </Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
