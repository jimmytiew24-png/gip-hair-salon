'use client';
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { team, type TeamMember, type ArtistId } from '@/content/team';
import { portfolio, serviceArtworks } from '@/content/artwork';
import { works, filters, services } from '@/content/site';
import type { Artwork } from './artwork-gallery';

type PublicArtwork = Artwork & { owner?: string };
type Catalog = {
  schema: 1;
  artists: TeamMember[];
  portfolio: Record<ArtistId, PublicArtwork[]>;
  services: Record<(typeof services)[number]['id'], PublicArtwork[]>;
  showcase: PublicArtwork[];
};
const Content = createContext<Catalog | null>(null);
const validImage = (image: unknown) => typeof image === 'string' && /^(?:portfolio\/[a-z0-9-]+\/[a-z0-9-]+|team\/[a-z0-9-]+|uploads\/[a-f0-9]{32}|0[4-9]-artwork)\.(?:jpg|jpeg|png|webp)$/.test(image);
const labels = (value: unknown): value is { en: string; zh: string } => !!value && typeof value === 'object' && typeof (value as {en?:unknown}).en === 'string' && typeof (value as {zh?:unknown}).zh === 'string';
function validArtworks(value: unknown): value is PublicArtwork[] {
  return Array.isArray(value) && value.length <= 3000 && value.every(item => item && typeof item.id === 'string' && validImage(item.image) && typeof item.category === 'string' && labels(item.label) && (!item.caption || labels(item.caption)) && (!item.post || /^https:\/\/www\.instagram\.com\//.test(item.post)));
}
function validCatalog(value: unknown): value is Catalog {
  if (!value || typeof value !== 'object') return false;
  const data = value as Catalog;
  return data.schema === 1 && Array.isArray(data.artists) && data.artists.length === team.length && team.every(person => data.artists.some(item => item.id === person.id && typeof item.name === 'string' && labels(item.role) && validImage(item.image) && typeof item.handle === 'string' && typeof item.instagram === 'string' && (!item.instagram || /^https:\/\/www\.instagram\.com\/[A-Za-z0-9_.]+\/$/.test(item.instagram)) && (!item.bio || labels(item.bio)))) && !!data.portfolio && team.every(person => validArtworks(data.portfolio[person.id])) && !!data.services && services.every(service => validArtworks(data.services[service.id])) && validArtworks(data.showcase);
}
export function ManagedContentProvider({ children }: { children: ReactNode }) {
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  useEffect(() => {
    let controller: AbortController | null = null;
    const load = async () => {
      controller?.abort();
      const request = new AbortController(); controller = request;
      const timeout = setTimeout(() => request.abort(), 10000);
      try {
        const response = await fetch('/content.php', { cache: 'no-store', credentials: 'omit', signal: request.signal });
        if (response.ok) { const data: unknown = await response.json(); if (validCatalog(data)) setCatalog(data); }
      } catch { /* The bundled catalogue remains available when hosting is offline. */ }
      finally { clearTimeout(timeout); }
    };
    void load();
    const refresh = () => { if (document.visibilityState === 'visible') void load(); };
    document.addEventListener('visibilitychange', refresh);
    return () => { controller?.abort(); document.removeEventListener('visibilitychange', refresh); };
  }, []);
  return <Content.Provider value={catalog}>{children}</Content.Provider>;
}
export function useTeamMembers(): TeamMember[] { return useContext(Content)?.artists ?? [...team]; }
export function usePortfolio(id: ArtistId): PublicArtwork[] { return useContext(Content)?.portfolio[id] ?? portfolio[id]; }
export function useServiceArtworks(): Record<(typeof services)[number]['id'], PublicArtwork[]> { return useContext(Content)?.services ?? serviceArtworks; }
export function useShowcaseWorks(): { works: { id: string; image: string; category: string; name: {en:string;zh:string}; detail: {en:string;zh:string} }[]; filters: {id:string;name:{en:string;zh:string}}[] } {
  const catalog = useContext(Content);
  if (!catalog) return { works: [...works], filters: [...filters] };
  const result = catalog.showcase.map(item => ({ id: item.id, image: item.image, category: item.category, name: { en: item.caption?.en || item.label.en, zh: item.caption?.zh || item.label.zh }, detail: item.label }));
  return { works: result, filters: [filters[0], ...[...new Set(result.map(item => item.category))].map(id => ({id, name: filters.find(item => item.id === id)?.name || result.find(item => item.category === id)!.detail}))] };
}
