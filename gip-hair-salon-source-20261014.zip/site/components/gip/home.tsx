'use client';
import { useState } from 'react';
import { ArrowDown, MoveHorizontal, ArrowLeft, ArrowRight } from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';
import {
  type Lang,
  pick,
  pathFor,
  services,
  salons,
} from '@/content/site';
import { SafeImage, MagnetLink, TextLink, Closing } from './foundation';
import { Button } from '@/components/ui/button';
import { TeamPreview } from './team';
import { brandStory } from '@/content/team';
import { useShowcaseWorks } from './managed-content';

export function SalonCompare({ lang }: { lang: Lang }) {
  const [position, setPosition] = useState(56);
  return (
    <div className="compare-shell">
      <div className="compare-stage">
        <SafeImage
          src="03-kota-damansara.jpg"
          alt={salons[1].alt[lang]}
          lang={lang}
          eager
        />
        <div
          className="compare-layer"
          style={{ clipPath: `inset(0 ${100 - position}% 0 0)` }}
        >
          <SafeImage
            src={salons[0].image}
            alt={salons[0].alt[lang]}
            lang={lang}
            eager
          />
        </div>
        <div className="compare-labels" aria-hidden="true">
          <span>{pick(lang, 'WARM TIMBER', '温暖木质')}</span>
          <span>{pick(lang, 'LIGHT & STONE', '光与石材')}</span>
        </div>
        <div className="compare-line" style={{ left: `${position}%` }}>
          <span>
            <MoveHorizontal size={21} strokeWidth={1.5} />
          </span>
        </div>
        <input
          className="compare-input"
          type="range"
          min="0"
          max="100"
          value={position}
          onChange={(e) => setPosition(Number(e.target.value))}
          aria-label={pick(
            lang,
            'Explore the salon atmospheres. Drag or use arrow keys.',
            '探索沙龙氛围，可拖动或使用方向键。',
          )}
          aria-valuetext={pick(
            lang,
            `${position}% warm timber, ${100 - position}% light and stone`,
            `温暖木质 ${position}%，光与石材 ${100 - position}%`,
          )}
        />
      </div>
      <div className="compare-caption">
        <span>01 — {pick(lang, 'THE GIP ATMOSPHERE', 'GIP 的空间氛围')}</span>
        <span>
          <MoveHorizontal size={16} />
          {pick(lang, 'Drag to explore', '拖动探索')}
        </span>
      </div>
    </div>
  );
}
export function WorkRail({ lang }: { lang: Lang }) {
  const { works } = useShowcaseWorks();
  const [ref, api] = useEmblaCarousel({ align: 'start', loop: false });
  return (
    <section className="work-section wrap" data-reveal>
      <div className="section-heading">
        <div>
          <span className="eyebrow">
            {pick(lang, '01 / SELECTED WORK', '01 / 精选作品')}
          </span>
          <h2>
            {pick(lang, 'Good hair.', '好发型，')}{' '}
            <em>{pick(lang, 'Your way.', '有你的样子。')}</em>
          </h2>
        </div>
        <div className="rail-controls">
          <Button
            className="icon-button"
            variant="outline"
            aria-label={pick(lang, 'Previous work', '上一组作品')}
            onClick={() => api?.scrollPrev()}
          >
            <ArrowLeft />
          </Button>
          <Button
            className="icon-button"
            variant="outline"
            aria-label={pick(lang, 'Next work', '下一组作品')}
            onClick={() => api?.scrollNext()}
          >
            <ArrowRight />
          </Button>
        </div>
      </div>
      <div className="work-viewport" ref={ref}>
        <div className="work-track">
          {works.map((w, i) => (
            <a
              href={pathFor(lang, 'work') + '#look-' + w.id}
              className="work-slide"
              key={w.id}
            >
              <SafeImage src={w.image} alt={w.name[lang]} lang={lang} />
              <div className="work-caption">
                <span>{w.name[lang]}</span>
                <span>0{i + 1}</span>
              </div>
              <p>{w.detail[lang]}</p>
            </a>
          ))}
        </div>
      </div>
      <div className="rail-bottom">
        <span>
          {pick(
            lang,
            'A few looks from the GIP chair.',
            '来自 GIP 座椅上的发型灵感。',
          )}
        </span>
        <TextLink href={pathFor(lang, 'work')}>
          {pick(lang, 'Explore all work', '探索全部作品')}
        </TextLink>
      </div>
    </section>
  );
}
export function Home({ lang }: { lang: Lang }) {
  return (
    <>
      <section className="hero wrap">
        <div className="hero-meta">
          <span>GIP HAIR SALON</span>
          <span>NILAI · KOTA DAMANSARA</span>
        </div>
        <div className="hero-grid">
          <div className="hero-copy">
            <span className="eyebrow" data-enter>
              {pick(lang, 'A NEW PERSPECTIVE ON YOU', '换个角度，发现自己')}
            </span>
            <h1 data-enter>
              {lang === 'en' ? (
                <>
                  Hair that
                  <br />
                  <em>moves</em>
                  <br />
                  with you.
                </>
              ) : (
                <>
                  让发型，
                  <br />
                  <em>自然流动。</em>
                </>
              )}
            </h1>
            <p data-enter>
              {pick(
                lang,
                'Cuts, colour and texture shaped around the way you wear your hair every day.',
                '从剪裁、染色到纹理设计，围绕你的日常习惯，找到真正适合你的发型。',
              )}
            </p>
            <div className="hero-links" data-enter>
              <MagnetLink href={pathFor(lang, 'visit')}>
                {pick(lang, 'Start a consultation', '开始咨询')}
              </MagnetLink>
              <TextLink href={pathFor(lang, 'work')}>
                {pick(lang, 'View our work', '查看作品')}
              </TextLink>
            </div>
          </div>
          <div className="hero-visual" data-enter>
            <SalonCompare lang={lang} />
            <span className="vertical-note" aria-hidden="true">
              SPACE FOR A NEW YOU
            </span>
          </div>
        </div>
        <div className="hero-bottom">
          <a href="#selected">
            <ArrowDown size={18} />
            {pick(lang, 'A little inspiration, below', '往下，发现一点灵感')}
          </a>
          <span>
            {pick(lang, 'SHAPE · COLOUR · TEXTURE', '轮廓 · 色彩 · 纹理')}
          </span>
        </div>
      </section>
      <div id="selected">
        <WorkRail lang={lang} />
      </div>
      <section className="home-services wrap" data-reveal>
        <div>
          <span className="eyebrow">
            {pick(lang, '02 / WHAT WE DO', '02 / 我们的服务')}
          </span>
          <h2>
            {pick(lang, 'Considered hair.', '认真对待，')}
            <br />
            <em>{pick(lang, 'Every detail.', '每一缕发丝。')}</em>
          </h2>
          <p>
            {pick(
              lang,
              'A new shape, a different tone, or simply a little care. It starts with a conversation.',
              '新的轮廓、不一样的色调，或是好好做一次护理。一切，从聊聊开始。',
            )}
          </p>
          <TextLink href={pathFor(lang, 'services')}>
            {pick(lang, 'Find your service', '探索服务')}
          </TextLink>
        </div>
        <div className="service-index">
          {services.map((s, i) => (
            <a key={s.id} href={pathFor(lang, 'services') + '#' + s.id}>
              <span className="index-label">0{i + 1}</span>
              <span>{s.name[lang]}</span>
              <ArrowRight size={22} />
            </a>
          ))}
        </div>
      </section>
      <section className="home-spaces" data-reveal>
        <div className="wrap">
          <div className="space-photo">
            <SafeImage
              src="03-kota-damansara.jpg"
              alt={salons[1].alt[lang]}
              lang={lang}
            />
            <span className="photo-corner">GIP / KOTA DAMANSARA</span>
          </div>
          <div className="space-copy">
            <span className="eyebrow">
              {pick(lang, '03 / OUR SPACES', '03 / 我们的空间')}
            </span>
            <h2>
              {pick(lang, 'Come in.', '走进来，')}
              <br />
              <em>{pick(lang, 'Settle in.', '慢下来。')}</em>
            </h2>
            <p>
              {pick(
                lang,
                'Two salons, one shared feeling. Find us in Nilai and Kota Damansara.',
                '两间沙龙，同一种亲切感。在汝来与哥打白沙罗，等你来坐坐。',
              )}
            </p>
            <TextLink href={pathFor(lang, 'salons')}>
              {pick(lang, 'Find your GIP', '找到你的 GIP')}
            </TextLink>
          </div>
        </div>
      </section>
      <TeamPreview lang={lang} />
      <section
        className="home-story wrap"
        aria-labelledby="home-story-title"
        data-reveal
      >
        <div className="story-image">
          <SafeImage
            src={salons[0].image}
            alt={salons[0].alt[lang]}
            lang={lang}
          />
          <span className="photo-corner">GIP / NILAI</span>
        </div>
        <div className="story-copy">
          <span className="eyebrow">
            {pick(lang, '05 / OUR STORY', '05 / 我们的故事')}
          </span>
          <h2 id="home-story-title">
            {pick(lang, 'Get to', '进一步，')}
            <br />
            <em>{pick(lang, 'Know Us.', '了解 GIP。')}</em>
          </h2>
          <div className="story-paragraphs">
            {brandStory[lang].map((paragraph) => (
              <p key={paragraph}>{paragraph}</p>
            ))}
          </div>
          <TextLink href={pathFor(lang, 'team')}>
            {pick(lang, 'Meet the people behind GIP', '认识 GIP 背后的团队')}
          </TextLink>
        </div>
      </section>
      <Closing lang={lang} />
    </>
  );
}
