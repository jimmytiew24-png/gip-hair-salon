'use client';
import { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  ArrowLeft,
  ArrowUpRight,
  Check,
  MessageCircle,
  RotateCcw,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { type Lang, pick, salons, services } from '@/content/site';
import { team } from '@/content/team';
import { useTeamMembers } from './managed-content';
import { PageIntro } from './experiences';

type Draft = {
  branch: string;
  service: string;
  stylist: string;
  treatment: string;
  preferredDate: string;
  notes: string;
  editedMessage: string;
  messageWasEdited: boolean;
};
const blank: Draft = {
  branch: '',
  service: '',
  stylist: '',
  treatment: '',
  preferredDate: '',
  notes: '',
  editedMessage: '',
  messageWasEdited: false,
};
const storageKey = 'gip-consult-draft-v1';
function todayLocal() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}
function validSaved(value: unknown): Draft {
  if (!value || typeof value !== 'object') return blank;
  const v = value as Partial<Draft>;
  return {
    branch: salons.some((s) => s.id === v.branch) ? v.branch! : '',
    service: services.some((s) => s.id === v.service) ? v.service! : '',
    stylist: typeof v.stylist === 'string' ? v.stylist.slice(0, 100) : '',
    treatment: typeof v.treatment === 'string' ? v.treatment.slice(0, 300) : '',
    preferredDate:
      typeof v.preferredDate === 'string' &&
      /^\d{4}-\d{2}-\d{2}$/.test(v.preferredDate)
        ? v.preferredDate
        : '',
    notes: typeof v.notes === 'string' ? v.notes.slice(0, 1000) : '',
    editedMessage:
      typeof v.editedMessage === 'string' ? v.editedMessage.slice(0, 4000) : '',
    messageWasEdited: v.messageWasEdited === true,
  };
}
export function ConsultationPage({ lang }: { lang: Lang }) {
  const managedTeam = useTeamMembers();
  const [draft, setDraft] = useState<Draft>(blank);
  const [ready, setReady] = useState(false);
  const [step, setStep] = useState(0);
  const [today, setToday] = useState('');
  const title = useRef<HTMLHeadingElement>(null);
  const moved = useRef(false);
  useEffect(() => {
    let initial = blank;
    try {
      initial = validSaved(
        JSON.parse(localStorage.getItem(storageKey) || 'null'),
      );
    } catch {
      /* Storage is optional. */
    }
    const query = new URLSearchParams(location.search);
    const branch = query.get('salon');
    const service = query.get('service');
    const stylist = team.find((person) => person.id === query.get('stylist'));
    if (salons.some((s) => s.id === branch))
      initial = { ...initial, branch: branch! };
    if (services.some((s) => s.id === service))
      initial = { ...initial, service: service! };
    if (stylist)
      initial = { ...initial, branch: 'nilai', stylist: stylist.name };
    // oxlint-disable-next-line react/react-compiler -- Restore browser-only storage after matching the static server render.
    setDraft(initial);
    setToday(todayLocal());
    setReady(true);
  }, []);
  useEffect(() => {
    if (ready) {
      try {
        localStorage.setItem(storageKey, JSON.stringify(draft));
      } catch {
        /* Continue in memory when storage is unavailable. */
      }
    }
  }, [draft, ready]);
  useEffect(() => {
    if (moved.current) title.current?.focus();
  }, [step]);
  const change = (values: Partial<Draft>) =>
    setDraft((d) => ({ ...d, ...values }));
  const currentStylist = managedTeam.find(person => person.id === team.find(original => original.name === draft.stylist)?.id);
  const stylistName = currentStylist?.name || draft.stylist;
  const salon = salons.find((s) => s.id === draft.branch);
  const service = services.find((s) => s.id === draft.service);
  const generated =
    lang === 'en'
      ? `Hi GIP Hair Salon, I'd like to ask about a visit.\n\nBranch: ${salon?.name.en || 'Choose a branch'}\nPreferred stylist: ${stylistName.trim() || 'No preference'}\nService: ${service?.name.en || 'Choose a service'}${draft.service === 'treatment' ? `\nTreatment request: ${draft.treatment.trim() || 'Please recommend a suitable treatment'}` : ''}\nPreferred date: ${draft.preferredDate || 'Flexible'}\nNotes: ${draft.notes.trim() || 'None'}\n\nPlease let me know what times are available.`
      : `你好 GIP，我想咨询到店服务。\n\n分店：${salon?.name.zh || '请选择分店'}\n发型师偏好：${stylistName.trim() || '无指定'}\n项目：${service?.name.zh || '请选择项目'}${draft.service === 'treatment' ? `\n护理需求：${draft.treatment.trim() || '请推荐适合我的护理'}` : ''}\n日期偏好：${draft.preferredDate || '时间灵活'}\n备注：${draft.notes.trim() || '暂无'}\n\n请问有什么可以安排的时段？谢谢！`;
  const message = draft.messageWasEdited ? draft.editedMessage : generated;
  const dateError =
    !!draft.preferredDate &&
    (draft.preferredDate < today ||
      !Number.isFinite(Date.parse(draft.preferredDate)));
  const canSend =
    ready && !!salon && !!service && !dateError && !!message.trim();
  const stepTitles =
    lang === 'en'
      ? ['Choose your branch.', 'What’s on your mind?', 'Make it your own.']
      : ['选择你的分店。', '这次，想做什么？', '加一点你的想法。'];
  function go(next: number) {
    moved.current = true;
    setStep(next);
  }
  return (
    <>
      <PageIntro
        lang={lang}
        number="06"
        kicker={pick(lang, 'A CONVERSATION STARTS HERE', '从这里，开始聊聊')}
        title={pick(lang, 'Your next', '你的下一段')}
        accent={pick(lang, 'hair chapter.', '发型故事。')}
        description={pick(
          lang,
          'Tell us what you’re thinking. We’ll help you put it into a message for your salon.',
          '告诉我们你想做什么，我们帮你整理成一则发给门店的咨询消息。',
        )}
      />
      <section className="consult-layout wrap">
        <div className="consult-builder">
          <nav
            className="step-rail"
            aria-label={pick(lang, 'Consultation steps', '咨询步骤')}
          >
            {stepTitles.map((_, i) => (
              <button
                key={i}
                disabled={
                  (i === 1 && !salon) || (i === 2 && (!salon || !service))
                }
                onClick={() => go(i)}
                aria-current={step === i ? 'step' : undefined}
              >
                <span>
                  {i < step ? (
                    <Check size={15} />
                  ) : (
                    String(i + 1).padStart(2, '0')
                  )}
                </span>
                {
                  (lang === 'en'
                    ? ['Branch', 'Service', 'Details']
                    : ['分店', '项目', '详情'])[i]
                }
              </button>
            ))}
          </nav>
          <div className="step-panel">
            <span className="eyebrow">
              {pick(
                lang,
                `STEP ${step + 1} OF 3`,
                `第 ${step + 1} 步，共 3 步`,
              )}
            </span>
            <h2 ref={title} tabIndex={-1}>
              {stepTitles[step]}
            </h2>
            {step === 0 && (
              <>
                <p>
                  {pick(
                    lang,
                    'Same GIP spirit. Pick the space closest to you.',
                    '同一个 GIP，选一家离你更近的门店。',
                  )}
                </p>
                <RadioGroup
                  className="branch-choices"
                  value={draft.branch}
                  onValueChange={(value) => change({ branch: String(value) })}
                  aria-label={pick(
                    lang,
                    'Choose a branch (required)',
                    '选择分店（必选）',
                  )}
                >
                  {salons.map((s) => (
                    <label
                      className="choice"
                      key={s.id}
                      htmlFor={`salon-${s.id}`}
                    >
                      <RadioGroupItem value={s.id} id={`salon-${s.id}`} />
                      <span>
                        <strong>{s.name[lang]}</strong>
                        <small>
                          {s.id === 'nilai'
                            ? 'Negeri Sembilan'
                            : 'Petaling Jaya, Selangor'}
                        </small>
                      </span>
                      <ArrowUpRight size={20} />
                    </label>
                  ))}
                </RadioGroup>
                <div className="detail-fields">
                  <label htmlFor="preferred-stylist">
                    {pick(lang, 'Preferred stylist', '发型师偏好')}
                    <span>{pick(lang, 'Optional', '选填')}</span>
                  </label>
                  <Input
                    id="preferred-stylist"
                    list={
                      draft.branch === 'nilai' ? 'nilai-stylists' : undefined
                    }
                    maxLength={100}
                    value={draft.stylist}
                    onChange={(e) => change({ stylist: e.target.value })}
                    placeholder={pick(
                      lang,
                      'Stylist’s name, or leave blank',
                      '填写发型师姓名，无指定可留空',
                    )}
                    aria-describedby="stylist-help"
                  />
                  {draft.branch === 'nilai' && (
                    <datalist id="nilai-stylists">
                      {managedTeam.map((person) => (
                        <option key={person.id} value={person.name}>
                          {person.name}
                        </option>
                      ))}
                    </datalist>
                  )}
                  <p id="stylist-help">
                    {pick(
                      lang,
                      'Your branch will confirm the stylist’s availability.',
                      '分店会进一步确认发型师的可预约时段。',
                    )}
                  </p>
                </div>
              </>
            )}
            {step === 1 && (
              <>
                <p>
                  {pick(
                    lang,
                    'Choose a starting point. You can add other ideas in your notes.',
                    '先选一个项目，其他想法可以写在备注里。',
                  )}
                </p>
                <RadioGroup
                  className="service-choices"
                  value={draft.service}
                  onValueChange={(value) => change({ service: String(value) })}
                  aria-label={pick(
                    lang,
                    'Choose a service (required)',
                    '选择项目（必选）',
                  )}
                >
                  {services.map((s) => (
                    <label
                      className="choice"
                      key={s.id}
                      htmlFor={`service-${s.id}`}
                    >
                      <RadioGroupItem value={s.id} id={`service-${s.id}`} />
                      <span>
                        <strong>{s.name[lang]}</strong>
                        <small>{s.subtitle[lang]}</small>
                      </span>
                    </label>
                  ))}
                </RadioGroup>
                {draft.service === 'treatment' && (
                  <div className="detail-fields">
                    <label htmlFor="treatment-request">
                      {pick(
                        lang,
                        'What treatment do you have in mind?',
                        '想做什么护理？',
                      )}
                      <span>{pick(lang, 'Optional', '选填')}</span>
                    </label>
                    <Textarea
                      id="treatment-request"
                      maxLength={300}
                      rows={3}
                      value={draft.treatment}
                      onChange={(e) => change({ treatment: e.target.value })}
                      placeholder={pick(
                        lang,
                        'A treatment name or what you’d like to improve about your hair or scalp…',
                        '填写护理名称，或描述想改善的发质、头皮状况……',
                      )}
                      aria-describedby="treatment-help"
                    />
                    <p id="treatment-help">
                      {pick(
                        lang,
                        'Not sure? Leave this blank and ask your branch for a recommendation.',
                        '还不确定？可以留空，请分店推荐适合的护理。',
                      )}
                    </p>
                  </div>
                )}
              </>
            )}
            {step === 2 && (
              <div className="detail-fields">
                <label htmlFor="preferred-date">
                  {pick(lang, 'Preferred date', '日期偏好')}
                  <span>{pick(lang, 'Optional', '选填')}</span>
                </label>
                <Input
                  id="preferred-date"
                  type="date"
                  min={today}
                  value={draft.preferredDate}
                  onChange={(e) => change({ preferredDate: e.target.value })}
                  aria-invalid={dateError}
                  aria-describedby={dateError ? 'date-error' : undefined}
                />
                {dateError && (
                  <p id="date-error" className="field-error" role="alert">
                    {pick(
                      lang,
                      'Choose today or a future date, or leave this blank.',
                      '请选择今天或之后的日期，也可以留空。',
                    )}
                  </p>
                )}
                <label htmlFor="consult-notes">
                  {pick(lang, 'Anything else in mind?', '还有什么想法？')}
                  <span>{pick(lang, 'Optional', '选填')}</span>
                </label>
                <Textarea
                  id="consult-notes"
                  maxLength={1000}
                  rows={5}
                  value={draft.notes}
                  onChange={(e) => change({ notes: e.target.value })}
                  placeholder={pick(
                    lang,
                    'Your current hair, a look you love, preferred time…',
                    '现在的发型、喜欢的风格、方便的时间……',
                  )}
                />
                <p>
                  {pick(
                    lang,
                    'You can share inspiration photos in WhatsApp after opening the conversation.',
                    '打开 WhatsApp 对话后，可以再发送你喜欢的发型参考图。',
                  )}
                </p>
              </div>
            )}
            <div className="step-actions">
              {step > 0 ? (
                <Button
                  variant="ghost"
                  className="back-button"
                  onClick={() => go(step - 1)}
                >
                  <ArrowLeft size={17} />
                  {pick(lang, 'Back', '上一步')}
                </Button>
              ) : (
                <span className="required-note">
                  {pick(
                    lang,
                    'A branch is required to continue.',
                    '选择分店后即可继续。',
                  )}
                </span>
              )}
              {step < 2 && (
                <Button
                  className="next-button"
                  disabled={!ready || (step === 0 ? !salon : !service)}
                  onClick={() => go(step + 1)}
                >
                  {pick(lang, 'Continue', '继续')}
                  <ArrowRight size={19} />
                </Button>
              )}
            </div>
          </div>
        </div>
        <aside className="message-sheet">
          <div className="message-sheet-top">
            <MessageCircle size={20} />
            <span>{pick(lang, 'YOUR CONSULTATION NOTE', '你的咨询消息')}</span>
            <span>GIP</span>
          </div>
          <label htmlFor="whatsapp-message">
            {pick(lang, 'A message, in your words.', '用你的话，聊聊发型。')}
          </label>
          <p>
            {pick(
              lang,
              'This draft is yours to edit.',
              '这份草稿，你可以自由修改。',
            )}
          </p>
          <Textarea
            id="whatsapp-message"
            rows={12}
            maxLength={4000}
            value={message}
            onChange={(e) =>
              change({ editedMessage: e.target.value, messageWasEdited: true })
            }
          />
          {draft.messageWasEdited && (
            <p className="draft-note">
              {pick(
                lang,
                'You’ve edited this message. Reset it to rebuild the draft from your current selections.',
                '你已修改这份消息。点击恢复自动生成内容，可根据当前选项重新整理草稿。',
              )}
            </p>
          )}
          <Button
            className="reset-message"
            variant="ghost"
            onClick={() =>
              change({ messageWasEdited: false, editedMessage: '' })
            }
          >
            <RotateCcw size={15} />
            {pick(lang, 'Reset generated message', '恢复自动生成内容')}
          </Button>
          <div className="message-check">
            <span className={salon ? 'chosen' : ''}>
              {salon ? <Check size={15} /> : <span className="mini-circle" />}
              {salon?.name[lang] || pick(lang, 'Choose a branch', '请选择分店')}
            </span>
            <span className={service ? 'chosen' : ''}>
              {service ? <Check size={15} /> : <span className="mini-circle" />}
              {service?.name[lang] ||
                pick(lang, 'Choose a service', '请选择项目')}
            </span>
          </div>
          {canSend ? (
            <a
              className="button-link whatsapp-link"
              href={`https://wa.me/${salon.phone}?text=${encodeURIComponent(message)}`}
              target="_blank"
              rel="noreferrer"
            >
              {pick(lang, 'Continue on WhatsApp', '通过 WhatsApp 咨询')}
              <ArrowUpRight size={20} />
            </a>
          ) : (
            <Button className="button-link whatsapp-link" disabled>
              {pick(lang, 'Continue on WhatsApp', '通过 WhatsApp 咨询')}
              <ArrowUpRight size={20} />
            </Button>
          )}
          <p className="confirmation-note">
            {pick(
              lang,
              'Your appointment is only confirmed after the salon replies. This opens WhatsApp; it doesn’t send the message for you.',
              '门店回复确认后，预约才正式成立。点击只会打开 WhatsApp，消息由你确认发送。',
            )}
          </p>
          <p className="draft-note">
            {pick(
              lang,
              'Your draft stays in this browser.',
              '草稿仅保存在当前浏览器。',
            )}
          </p>
        </aside>
      </section>
      <noscript>
        <section className="wrap no-script">
          <p>
            {pick(
              lang,
              'Contact your salon directly on WhatsApp. Your appointment needs the salon’s confirmation.',
              '你可以直接通过 WhatsApp 联系门店，预约需经门店确认。',
            )}
          </p>
          {salons.map((s) => (
            <a
              className="button-link"
              key={s.id}
              href={'https://wa.me/' + s.phone}
            >
              {s.name[lang]} · {s.displayPhone}
            </a>
          ))}
        </section>
      </noscript>
      <div className="consult-bottom wrap">
        <span>{pick(lang, 'Prefer to call?', '想直接打电话？')}</span>
        {salons.map((s) => (
          <a key={s.id} href={'tel:+' + s.phone}>
            {s.name[lang]}
            <ArrowUpRight size={17} />
          </a>
        ))}
        <a
          href="https://www.facebook.com/GIPHairSalon"
          target="_blank"
          rel="noreferrer"
        >
          Facebook <ArrowUpRight size={17} />
        </a>
      </div>
    </>
  );
}
