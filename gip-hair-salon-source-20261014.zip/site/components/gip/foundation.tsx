'use client';
import {
  useEffect,
  useRef,
  useState,
  type ReactNode,
  type CSSProperties,
} from 'react';
import { animate, createScope, stagger } from 'animejs';
import { ArrowUpRight, Menu, X, ArrowRight } from 'lucide-react';
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ManagedContentProvider } from './managed-content';
import {
  type Lang,
  type PageName,
  pick,
  pathFor,
  nav,
  pages,
  salons,
  hours,
} from '@/content/site';

export function SafeImage({
  src,
  alt,
  lang,
  className = '',
  eager = false,
  style,
}: {
  src: string;
  alt: string;
  lang: Lang;
  className?: string;
  eager?: boolean;
  style?: CSSProperties;
}) {
  const [failedSource, setFailedSource] = useState('');
  return (
    <div className={`safe-image ${className}${src.startsWith('uploads/') ? ' managed-photo' : ''}`} style={style}>
      {failedSource === src ? (
        <span className="image-fallback">
          {pick(lang, 'Image unavailable', '图片暂不可用')}
        </span>
      ) : (
        // oxlint-disable-next-line nextjs/no-img-element -- Optimized local JPEGs are served by a portable static server.
        <img
          ref={(element) => {
            if (element?.complete && element.naturalWidth === 0)
              setFailedSource(src);
          }}
          src={`/images/${src}`}
          alt={alt}
          loading={eager ? 'eager' : 'lazy'}
          fetchPriority={eager ? 'high' : 'auto'}
          decoding="async"
          onError={() => setFailedSource(src)}
        />
      )}
    </div>
  );
}
export function MagnetLink({
  href,
  children,
  className = '',
}: {
  href: string;
  children: ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLAnchorElement>(null);
  return (
    <a
      ref={ref}
      href={href}
      className={`button-link magnetic ${className}`}
      onPointerMove={(e) => {
        if (
          !matchMedia(
            '(pointer: fine) and (prefers-reduced-motion: no-preference)',
          ).matches
        )
          return;
        const r = e.currentTarget.getBoundingClientRect();
        e.currentTarget.style.transform = `translate(${Math.max(-8, Math.min(8, (e.clientX - r.left - r.width / 2) * 0.08))}px,${Math.max(-8, Math.min(8, (e.clientY - r.top - r.height / 2) * 0.15))}px)`;
      }}
      onPointerLeave={() => {
        if (ref.current) ref.current.style.transform = '';
      }}
    >
      {children}
      <ArrowUpRight size={19} strokeWidth={1.5} />
    </a>
  );
}
export function TextLink({
  href,
  children,
}: {
  href: string;
  children: ReactNode;
}) {
  return (
    <a className="text-link" href={href}>
      {children}
      <ArrowUpRight size={20} strokeWidth={1.5} />
    </a>
  );
}
export function LanguageLink({
  lang,
  page,
  member,
}: {
  lang: Lang;
  page: PageName;
  member?: string;
}) {
  const href =
    pathFor(lang === 'en' ? 'zh' : 'en', page) + (member ? member + '/' : '');
  return (
    <a
      className="language-link"
      href={href}
      hrefLang={lang === 'en' ? 'zh-CN' : 'en'}
      lang={lang === 'en' ? 'zh-CN' : 'en'}
      aria-label={pick(lang, 'Switch to Chinese', 'Switch to English')}
      onClick={(e) => {
        e.currentTarget.href = href + window.location.hash;
      }}
    >
      {lang === 'en' ? '中文' : 'EN'}
      <span aria-hidden="true">↗</span>
    </a>
  );
}
function Header({
  lang,
  page,
  member,
}: {
  lang: Lang;
  page: PageName;
  member?: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <header className="header wrap">
      <a className="wordmark" href={pathFor(lang)} aria-label="GIP Hair Salon">
        <SafeImage
          src="gip-logo-en.png"
          alt="GIP hair salon"
          lang={lang}
          className="brand-logo"
          eager
        />
      </a>
      <nav
        className="desktop-nav"
        aria-label={pick(lang, 'Main navigation', '主导航')}
      >
        {pages.slice(0, 5).map((p, i) => (
          <a
            key={p}
            href={pathFor(lang, p)}
            aria-current={page === p ? 'page' : undefined}
          >
            {nav[lang][i]}
          </a>
        ))}
      </nav>
      <div className="header-actions">
        <LanguageLink lang={lang} page={page} member={member} />
        <a className="header-cta" href={pathFor(lang, 'visit')}>
          {pick(lang, 'Let’s talk hair', '聊聊你的发型')}
          <ArrowUpRight size={17} />
        </a>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger
            render={
              <Button
                className="mobile-menu-button icon-button"
                variant="ghost"
                aria-label={pick(lang, 'Open menu', '打开菜单')}
              />
            }
          >
            <Menu size={24} />
          </DialogTrigger>
          <DialogContent className="mobile-menu" showCloseButton={false}>
            <div className="menu-top">
              <DialogTitle>
                <SafeImage
                  src="gip-logo-en.png"
                  alt="GIP hair salon"
                  lang={lang}
                  className="brand-logo"
                />
              </DialogTitle>
              <DialogClose
                render={
                  <Button
                    variant="ghost"
                    className="icon-button"
                    aria-label={pick(lang, 'Close menu', '关闭菜单')}
                  />
                }
              >
                <X />
              </DialogClose>
            </div>
            <DialogDescription className="sr-only">
              {pick(lang, 'Explore GIP Hair Salon', '探索 GIP 边缘设计')}
            </DialogDescription>
            <nav>
              {pages.map((p, i) => (
                <a
                  key={p}
                  href={pathFor(lang, p)}
                  aria-current={page === p ? 'page' : undefined}
                >
                  <span className="index-label">0{i + 1}</span>
                  {nav[lang][i]}
                  <ArrowUpRight />
                </a>
              ))}
            </nav>
            <p>{pick(lang, 'Nilai · Kota Damansara', '汝来 · 哥打白沙罗')}</p>
          </DialogContent>
        </Dialog>
      </div>
    </header>
  );
}
export function Closing({ lang }: { lang: Lang }) {
  return (
    <section className="closing wrap" data-reveal>
      <div>
        <span className="eyebrow">
          {pick(lang, 'YOUR NEXT CHAPTER', '你的下一段发型故事')}
        </span>
        <h2>
          {pick(lang, 'A little change.', '一点改变，')}
          <br />
          <em>{pick(lang, 'A little more you.', '更像自己。')}</em>
        </h2>
      </div>
      <MagnetLink className="round-link" href={pathFor(lang, 'visit')}>
        {pick(lang, 'Let’s talk hair', '聊聊你的发型')}
      </MagnetLink>
    </section>
  );
}
function Footer({ lang }: { lang: Lang }) {
  return (
    <footer className="footer">
      <div className="wrap footer-main">
        <div>
          <a className="footer-logo" href={pathFor(lang)}>
            <SafeImage
              src="gip-logo-en.png"
              alt="GIP hair salon"
              lang={lang}
              className="brand-logo footer-brand-logo"
            />
          </a>
          <p>{pick(lang, 'Hair, with a point of view.', '发型，自有态度。')}</p>
          <div className="footer-socials">
            <a
              href="https://www.instagram.com/gip.hairsalon/"
              target="_blank"
              rel="noreferrer"
              className="text-link"
            >
              Instagram <ArrowUpRight size={17} />
            </a>
            <a
              href="https://www.facebook.com/GIPHairSalon"
              target="_blank"
              rel="noreferrer"
              className="text-link"
            >
              Facebook <ArrowUpRight size={17} />
            </a>
          </div>
        </div>
        {salons.map((s) => (
          <div key={s.id}>
            <h3>{s.name[lang]}</h3>
            <p>{s.address}</p>
            <a href={`tel:+${s.phone}`}>{s.displayPhone}</a>
            <a
              className="footer-whatsapp"
              href={`https://wa.me/${s.phone}`}
              target="_blank"
              rel="noreferrer"
            >
              WhatsApp <ArrowUpRight size={17} />
            </a>
          </div>
        ))}
      </div>
      <div className="wrap footer-bottom">
        <p>{hours[lang]}</p>
        <a href="mailto:giphairsalon1@gmail.com">giphairsalon1@gmail.com</a>
        <span>© {new Date().getFullYear()} GIP Hair Salon</span>
      </div>
    </footer>
  );
}
export function SiteShell({
  lang,
  page,
  children,
  member,
}: {
  lang: Lang;
  page: PageName;
  children: ReactNode;
  member?: string;
}) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const media = matchMedia('(prefers-reduced-motion: reduce)');
    let cleanup = () => {};
    const setup = () => {
      cleanup();
      if (media.matches) return;
      const scope = createScope({ root }).add(() => {
        animate('[data-enter]', {
          opacity: [0, 1],
          translateY: [20, 0],
          delay: stagger(90),
          duration: 620,
          ease: 'out(3)',
        });
      });
      const observer = new IntersectionObserver(
        (entries) =>
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              observer.unobserve(entry.target);
              scope.add(() => {
                animate(entry.target, {
                  opacity: [0.3, 1],
                  translateY: [18, 0],
                  duration: 460,
                  ease: 'out(3)',
                });
              });
            }
          }),
        { threshold: 0.08 },
      );
      root.current
        ?.querySelectorAll('[data-reveal]')
        .forEach((el) => observer.observe(el));
      cleanup = () => {
        observer.disconnect();
        scope.revert();
      };
    };
    setup();
    media.addEventListener('change', setup);
    return () => {
      cleanup();
      media.removeEventListener('change', setup);
    };
  }, [page, lang, member]);
  return (
    <ManagedContentProvider><div ref={root} className={`site lang-${lang}`}>
      <a href="#main" className="skip-link">
        {pick(lang, 'Skip to content', '跳至内容')}
      </a>
      <Header lang={lang} page={page} member={member} />
      <noscript>
        <nav
          className="no-js-nav wrap"
          aria-label={pick(lang, 'Page navigation', '页面导航')}
        >
          {pages.map((item, i) => (
            <a key={item} href={pathFor(lang, item)}>
              {nav[lang][i]}
            </a>
          ))}
        </nav>
      </noscript>
      <main id="main" tabIndex={-1}>
        {children}
      </main>
      <Footer lang={lang} />
      <a
        className="back-top"
        href="#main"
        aria-label={pick(lang, 'Back to top', '返回顶部')}
      >
        <ArrowRight size={20} />
      </a>
    </div></ManagedContentProvider>
  );
}
