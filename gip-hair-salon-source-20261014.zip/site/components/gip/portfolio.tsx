'use client';
import { ArrowLeft, ArrowUpRight } from 'lucide-react';
import { type Lang, pathFor, pick } from '@/content/site';
import { consultWith, type TeamMember } from '@/content/team';
import { portfolioPath } from '@/content/artwork';
import { usePortfolio, useTeamMembers } from './managed-content';
import { SafeImage, TextLink } from './foundation';
import { ArtworkGallery } from './artwork-gallery';

export function PortfolioPage({
  lang,
  person: initialPerson,
}: {
  lang: Lang;
  person: TeamMember;
}) {
  const team = useTeamMembers();
  const person = team.find(member => member.id === initialPerson.id) ?? initialPerson;
  const artworks = usePortfolio(person.id);
  return (
    <>
      <section className="portfolio-intro wrap">
        <a
          className="portfolio-back"
          href={pathFor(lang, 'team') + '#' + person.id}
        >
          <ArrowLeft size={18} />
          {pick(lang, 'Back to the team', '返回团队')}
        </a>
        <div className="portfolio-intro-grid">
          <div className="portfolio-copy">
            <span className="eyebrow" data-enter>
              {pick(lang, 'NILAI / SELECTED WORK', '汝来 / 作品精选')}
            </span>
            <h1 data-enter>
              {person.name}
              <br />
              <em>{pick(lang, 'A closer look.', '细看作品。')}</em>
            </h1>
            <p className="portfolio-role" data-enter>
              {person.role[lang]}
            </p>
            {person.bio?.[lang] && <p className="portfolio-bio">{person.bio[lang]}</p>}
            <div className="portfolio-actions">
              <TextLink href={consultWith(lang, person)}>
                {pick(
                  lang,
                  `Consult with ${person.name}`,
                  `咨询 ${person.name}`,
                )}
              </TextLink>
              {person.instagram && <a href={person.instagram} target="_blank" rel="noreferrer">
                @{person.handle} <ArrowUpRight size={17} />
              </a>}
            </div>
          </div>
          <SafeImage
            src={person.image}
            alt={person.name}
            lang={lang}
            className="team-portrait portfolio-portrait"
            eager
          />
        </div>
      </section>
      <nav
        className="portfolio-people wrap"
        aria-label={pick(lang, 'Stylist portfolios', '发型师作品集')}
      >
        {team.map((member) => (
          <a
            key={member.id}
            href={portfolioPath(lang, member)}
            aria-current={member.id === person.id ? 'page' : undefined}
          >
            {member.name}
          </a>
        ))}
      </nav>
      <section
        className="portfolio-work wrap"
        aria-label={`${person.name} ${pick(lang, 'artwork', '作品')}`}
      >
        <ArtworkGallery
          items={artworks}
          owner={person.name}
          lang={lang}
        />
      </section>
      <section className="portfolio-cta wrap">
        <h2>
          {pick(lang, 'Something caught', '有喜欢的，')}
          <br />
          <em>{pick(lang, 'your eye?', '发型吗？')}</em>
        </h2>
        <TextLink href={consultWith(lang, person)}>
          {pick(lang, 'Let’s talk about your look', '聊聊你的发型')}
        </TextLink>
      </section>
    </>
  );
}
