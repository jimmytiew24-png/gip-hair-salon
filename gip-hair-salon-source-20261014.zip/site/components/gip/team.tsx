'use client';
import { useState } from 'react';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import { type Lang, pick, pathFor } from '@/content/site';
import { consultWith, type TeamMember } from '@/content/team';
import { useTeamMembers } from './managed-content';
import { portfolioPath } from '@/content/artwork';
import { SafeImage, TextLink, Closing } from './foundation';
import { PageIntro } from './experiences';

function TeamCard({
  person,
  lang,
  preview = false,
  index,
}: {
  person: TeamMember;
  lang: Lang;
  preview?: boolean;
  index: number;
}) {
  return (
    <article
      className="team-card"
      id={preview ? undefined : person.id}
      data-reveal
    >
      <a
        className="team-photo-link"
        href={portfolioPath(lang, person)}
        aria-label={pick(
          lang,
          `${preview ? 'Meet' : 'View artwork by'} ${person.name}`,
          `${preview ? '认识' : '查看作品：'} ${person.name}`,
        )}
      >
        <SafeImage
          src={person.image}
          alt={`${person.name} · ${person.role[lang]}`}
          lang={lang}
          className="team-portrait"
        />
        <span className="team-photo-cue" aria-hidden="true">
          <ArrowUpRight size={22} />
        </span>
      </a>
      <div className="team-card-meta">
        <span>NILAI / GIP</span>
        <span>{String(index + 1).padStart(2, '0')}</span>
      </div>
      <h3>{person.name}</h3>
      <p className="team-role">{person.role[lang]}</p>
      {preview ? (
        <TextLink href={portfolioPath(lang, person)}>
          {pick(lang, 'Meet your stylist', '认识发型师')}
        </TextLink>
      ) : (
        <>
          {person.instagram && <a
            className="team-instagram"
            href={person.instagram}
            target="_blank"
            rel="noreferrer"
          >
            @{person.handle} <ArrowUpRight size={16} />
          </a>}
          <div className="team-card-actions">
            <a href={portfolioPath(lang, person)}>
              {pick(lang, 'View artwork', '查看作品')}
              <ArrowUpRight size={17} />
            </a>
            <a
              href={consultWith(lang, person)}
              aria-label={pick(
                lang,
                `Consult with ${person.name}`,
                `咨询 ${person.name}`,
              )}
            >
              {pick(lang, 'Let’s talk', '聊聊发型')}
              <ArrowRight size={17} />
            </a>
          </div>
        </>
      )}
    </article>
  );
}
export function TeamPreview({ lang }: { lang: Lang }) {
  const team = useTeamMembers();
  return (
    <section
      className="home-team wrap"
      aria-labelledby="home-team-title"
      data-reveal
    >
      <div className="section-heading">
        <div>
          <span className="eyebrow">
            {pick(lang, '04 / THE PEOPLE OF GIP', '04 / GIP 的团队')}
          </span>
          <h2 id="home-team-title">
            {pick(lang, 'The people.', '认识团队，')}
            <br />
            <em>{pick(lang, 'Behind your look.', '找到你的发型师。')}</em>
          </h2>
        </div>
        <TextLink href={pathFor(lang, 'team')}>
          {pick(lang, 'Meet the Nilai team', '认识汝来团队')}
        </TextLink>
      </div>
      <div className="team-grid">
        {team.slice(0, 3).map((person, index) => (
          <TeamCard
            key={person.id}
            person={person}
            index={index}
            lang={lang}
            preview
          />
        ))}
      </div>
    </section>
  );
}
const categories = [
  { id: 'all', en: 'All team', zh: '全部成员' },
  { id: 'hair', en: 'Hair', zh: '发型设计' },
  { id: 'colour', en: 'Colour', zh: '染发' },
  { id: 'care', en: 'Scalp care', zh: '头皮护理' },
] as const;
export function TeamPage({ lang }: { lang: Lang }) {
  const team = useTeamMembers();
  const [category, setCategory] = useState<string>('all');
  const shown = team.filter(
    (person) => category === 'all' || person.category === category,
  );
  return (
    <>
      <PageIntro
        lang={lang}
        number="05"
        kicker={pick(lang, 'MEET THE NILAI TEAM', '认识汝来团队')}
        title={pick(lang, 'A familiar face.', '从认识，')}
        accent={pick(lang, 'A fresh perspective.', '到信任。')}
        description={pick(
          lang,
          'Meet the people at GIP Nilai. Explore their work, find a familiar face, and start a conversation about your next look.',
          '认识 GIP 汝来的团队，看看他们的作品，找到熟悉的面孔，聊聊你的下一款发型。',
        )}
      />
      <section
        className="team-directory wrap"
        aria-label={pick(lang, 'Nilai team profiles', '汝来团队资料')}
      >
        <div className="team-directory-top">
          <fieldset
            className="team-filters"
            aria-label={pick(lang, 'Filter team by role', '按职务筛选团队')}
          >
            {categories.map((item) => (
              <button
                key={item.id}
                type="button"
                aria-pressed={category === item.id}
                onClick={() => setCategory(item.id)}
              >
                {item[lang]}
              </button>
            ))}
          </fieldset>
          <p aria-live="polite">
            {pick(
              lang,
              `${shown.length} people · Nilai`,
              `${shown.length} 位成员 · 汝来`,
            )}
          </p>
        </div>
        <div className="team-grid">
          {shown.map((person) => (
            <TeamCard
              key={person.id}
              person={person}
              lang={lang}
              index={team.indexOf(person)}
            />
          ))}
        </div>
        <p className="team-availability">
          {pick(
            lang,
            'Stylist availability is confirmed by the Nilai branch when you enquire.',
            '咨询时，汝来分店会进一步确认发型师的可预约时段。',
          )}
        </p>
      </section>
      <Closing lang={lang} />
    </>
  );
}
