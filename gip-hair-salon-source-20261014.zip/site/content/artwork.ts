import catalog from './portfolio.json';
import { type Lang, pathFor } from './site';
import { type TeamMember } from './team';

export const portfolio = catalog;
export const portfolioPath = (lang: Lang, person: TeamMember) =>
  pathFor(lang, 'team') + person.id + '/';
export const serviceArtworks = {
  cut: portfolio['lim-wei-lun']
    .filter((item) => item.category === 'Female Haircut')
    .slice(0, 3),
  colour: portfolio.kay.filter((item) => item.category === 'Color').slice(0, 3),
  perm: portfolio['kaa-yen']
    .filter((item) => item.category === 'Perm')
    .slice(0, 3),
  treatment: portfolio.sky
    .filter((item) => item.category === 'Scalp Treatment')
    .slice(0, 3),
  extensions: portfolio['kaa-yen']
    .filter((item) => item.category === 'Hair Extension')
    .slice(0, 3),
};
export const serviceArtist = {
  cut: 'lim-wei-lun',
  colour: 'kay',
  perm: 'kaa-yen',
  treatment: 'sky',
  extensions: 'kaa-yen',
} as const;
