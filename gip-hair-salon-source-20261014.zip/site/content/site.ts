export type Lang = 'en' | 'zh';
export type PageName =
  | 'home'
  | 'services'
  | 'work'
  | 'salons'
  | 'team'
  | 'visit';
export const pages: PageName[] = [
  'home',
  'services',
  'work',
  'salons',
  'team',
  'visit',
];
export const pick = (lang: Lang, en: string, zh: string) =>
  lang === 'zh' ? zh : en;
export const pathFor = (lang: Lang, page: PageName = 'home') =>
  `${lang === 'zh' ? '/zh' : ''}/${page === 'home' ? '' : page + '/'}`;
export const nav = {
  en: ['Home', 'Services', 'Work', 'Salons', 'Team', 'Visit'],
  zh: ['首页', '服务', '作品', '门店', '发型师', '咨询'],
};
export const hours = {
  en: 'Daily 10:30–19:30. Please confirm availability with the salon.',
  zh: '每日 10:30–19:30；具体可预约时段请向门店确认。',
};
export const salons = [
  {
    id: 'nilai',
    name: { en: 'Nilai', zh: '汝来' },
    phone: '60186681383',
    displayPhone: '+60 18-668 1383',
    address: 'No.26, Melati Square Putra Nilai, 71800 Nilai, Negeri Sembilan.',
    image: '02-nilai-interior.png',
    description: {
      en: 'Warm timber, open space and softly lit mirrors. A familiar place for a fresh perspective.',
      zh: '温暖木质、开阔空间与柔和镜前灯光，在熟悉的地方，遇见新的自己。',
    },
    alt: {
      en: 'Updated GIP Nilai interior with timber shelves, styling mirrors and a white reception counter',
      zh: 'GIP 汝来门店的新室内照片，木质陈列架、造型镜面与白色接待台',
    },
  },
  {
    id: 'kd',
    name: { en: 'Kota Damansara', zh: '哥打白沙罗' },
    phone: '60174361383',
    displayPhone: '+60 17-436 1383',
    address:
      '30-2 & 32-2, Jalan PJU 5/11, Dataran Sunway, Kota Damansara, 47810 Petaling Jaya, Selangor.',
    image: '03-kota-damansara.jpg',
    description: {
      en: 'Pale timber, cool stone and light-filled mirrors. A little room to slow down.',
      zh: '浅木、灰石与映着光的镜面，让脚步慢下来，留一点时间给自己。',
    },
    alt: {
      en: 'Bright GIP Kota Damansara interior with pale wood, stone counters and cream chairs',
      zh: 'GIP 哥打白沙罗明亮室内，浅木柜、石材台面与奶油色座椅',
    },
  },
] as const;
export const services = [
  {
    id: 'cut',
    name: { en: 'Haircut', zh: '剪发' },
    subtitle: { en: 'Shape & movement', zh: '轮廓与动态' },
    description: {
      en: 'Shape, balance and movement built around your length and daily routine.',
      zh: '根据长度、脸部比例与日常整理习惯，调整轮廓、平衡与发丝动态。',
    },
    image: 'portfolio/lim-wei-lun/lim-wei-lun-07.jpg',
  },
  {
    id: 'colour',
    name: { en: 'Colour', zh: '染发' },
    subtitle: { en: 'A tone of your own', zh: '找到你的色调' },
    description: {
      en: 'From subtle dimension to a new colour direction. Bring the shades you love, and we’ll talk through the possibilities.',
      zh: '从细腻层次到全新色彩，带上你喜欢的参考图，一起讨论适合你的染发方向。',
    },
    image: 'portfolio/kay/kay-01.jpg',
  },
  {
    id: 'perm',
    name: { en: 'Perm', zh: '烫发' },
    subtitle: { en: 'Texture, naturally', zh: '自然的纹理' },
    description: {
      en: 'Soft curl and texture direction with natural movement in mind.',
      zh: '以自然动态为重点，设计柔和卷度与发丝纹理。',
    },
    image: 'portfolio/kaa-yen/kaa-yen-01.jpg',
  },
  {
    id: 'treatment',
    name: { en: 'Treatment', zh: '护理' },
    subtitle: { en: 'Time for your hair', zh: '好好照顾发丝' },
    description: {
      en: 'Hair-care options for softness, manageability and overall condition.',
      zh: '针对柔顺度、易整理程度与整体发质状态，讨论适合的护理选择。',
    },
    image: 'portfolio/sky/sky-25.png',
  },
  {
    id: 'extensions',
    name: { en: 'Extensions', zh: '接发' },
    subtitle: { en: 'Explore a new length', zh: '探索新的长度' },
    description: {
      en: 'Consultation for added length or volume. Suitability is confirmed with the salon.',
      zh: '针对增加长度或发量的接发咨询，实际适合程度由门店进一步确认。',
    },
    image: 'portfolio/kaa-yen/kaa-yen-13.jpg',
  },
] as const;
export const works = [
  {
    id: '04',
    image: '04-artwork.jpg',
    name: { en: 'Soft ash-brown waves', zh: '柔雾棕卷发' },
    category: 'soft',
    detail: { en: 'Soft tones · Loose movement', zh: '柔和色调 · 轻盈动态' },
  },
  {
    id: '05',
    image: '05-artwork.jpg',
    name: { en: 'Rose-copper waves', zh: '玫瑰铜波浪' },
    category: 'statement',
    detail: { en: 'Rose copper · Warm colour', zh: '玫瑰铜色 · 温暖色调' },
  },
  {
    id: '06',
    image: '06-artwork.jpg',
    name: { en: 'Contrast in the layers', zh: '层次撞色' },
    category: 'contrast',
    detail: { en: 'Light brown · Dark tips', zh: '浅棕层次 · 深色发尾' },
  },
  {
    id: '07',
    image: '07-artwork.jpg',
    name: { en: 'Smoky silver movement', zh: '烟灰银波浪' },
    category: 'soft',
    detail: { en: 'Smoky silver · Soft waves', zh: '烟灰银色 · 柔和波浪' },
  },
  {
    id: '08',
    image: '08-artwork.jpg',
    name: { en: 'Face-framing highlights', zh: '勾勒脸型的挑染' },
    category: 'contrast',
    detail: { en: 'Bright framing · Dark base', zh: '明亮轮廓 · 深色底色' },
  },
  {
    id: '09',
    image: '09-artwork.jpg',
    name: { en: 'Vivid copper waves', zh: '明亮铜橘卷发' },
    category: 'statement',
    detail: { en: 'Vivid copper · Fluid shape', zh: '明亮铜橘 · 流动线条' },
  },
] as const;
export const filters = [
  { id: 'all', name: { en: 'All work', zh: '全部作品' } },
  { id: 'soft', name: { en: 'Soft tones', zh: '柔和色调' } },
  { id: 'statement', name: { en: 'Statement colour', zh: '鲜明色彩' } },
  { id: 'contrast', name: { en: 'Contrast', zh: '层次对比' } },
] as const;
