import { type Lang, pathFor } from './site';

export const team = [
  {
    id: 'lim-wei-lun',
    name: 'Lim Wei Lun',
    role: { en: 'Director', zh: '发型总监' },
    category: 'hair',
    image: 'team/lim-wei-lun.jpg',
    handle: 'lun_giphairsalon',
    instagram: 'https://www.instagram.com/lun_giphairsalon/',
    artwork: 'https://giphairsalon1.wixsite.com/gip-hair-salon/copy-of-mike',
  },
  {
    id: 'kaa-yen',
    name: 'Kaa Yen',
    role: { en: 'Director', zh: '发型总监' },
    category: 'hair',
    image: 'team/kaa-yen.jpg',
    handle: 'kaayen_giphairsalon',
    instagram: 'https://www.instagram.com/kaayen_giphairsalon/',
    artwork: 'https://giphairsalon1.wixsite.com/gip-hair-salon/projects-8',
  },
  {
    id: 'oscar',
    name: 'Oscar',
    role: { en: 'Hairstylist', zh: '发型师' },
    category: 'hair',
    image: 'team/oscar.jpg',
    handle: 'oscarloo1118',
    instagram: 'https://www.instagram.com/oscarloo1118/',
    artwork: 'https://www.instagram.com/oscarloo1118/',
  },
  {
    id: 'kay',
    name: 'Kay',
    role: { en: 'Junior Hair Colorist', zh: '初级染发师' },
    category: 'colour',
    image: 'team/kay.jpg',
    handle: 'kay_giphairsalon',
    instagram: 'https://www.instagram.com/kay_giphairsalon/',
    artwork: 'https://giphairsalon1.wixsite.com/gip-hair-salon/copy-of-joe',
  },
  {
    id: 'junting',
    name: 'Junting',
    role: { en: 'Junior Hairstylist', zh: '初级发型师' },
    category: 'hair',
    image: 'team/junting.jpg',
    handle: 'junl_junk',
    instagram: 'https://www.instagram.com/junl_junk/',
    artwork: 'https://giphairsalon1.wixsite.com/gip-hair-salon/copy-of-ken',
  },
  {
    id: 'sky',
    name: 'Sky',
    role: { en: 'Makeup Artist / Scalp Therapist', zh: '化妆师／头皮护理师' },
    category: 'care',
    image: 'team/sky.jpg',
    handle: 'sky_cmua',
    instagram: 'https://www.instagram.com/sky_cmua/',
    artwork: 'https://giphairsalon1.wixsite.com/gip-hair-salon/copy-of-wei-ah',
  },
] as const;
export type ArtistId = (typeof team)[number]['id'];
export type TeamMember = {
  id: ArtistId;
  name: string;
  role: { en: string; zh: string };
  category: 'hair' | 'colour' | 'care';
  image: string;
  handle: string;
  instagram: string;
  artwork?: string;
  bio?: { en: string; zh: string };
};
export function consultWith(lang: Lang, person: TeamMember) {
  const query = new URLSearchParams({ salon: 'nilai', stylist: person.id });
  if (person.id === 'sky') query.set('service', 'treatment');
  return pathFor(lang, 'visit') + '?' + query.toString();
}
export const brandStory = {
  en: [
    'GIP Hair Salon is an award-winning salon known for its dedication to quality, style, and customer care. With a team of highly skilled stylists boasting over 10 years of experience, we specialize in professional haircuts, creative coloring, expert perming, and customized treatments to suit every client’s unique needs.',
    'Founded in Nilai, GIP Hair Salon has become a trusted name in the local beauty industry — and in August 2024, we proudly expanded with a new branch in Kota Damansara, bringing our signature service and passion for hair to even more clients.',
    "At GIP, we believe that great hair isn't just about looking good — it's about feeling confident. Whether you're here for a quick trim or a total transformation, our mission is to make you look and feel your best.",
  ],
  zh: [
    'GIP Hair Salon 是屡获奖项的美发沙龙，始终专注于品质、风格与顾客体验。团队拥有逾十年的专业经验，提供专业剪发、创意染发、精细烫发与个性化护理，照顾每位顾客不同的需求。',
    'GIP 创立于汝来，逐渐成为本地美发行业值得信赖的品牌。2024 年 8 月，我们在哥打白沙罗开设新分店，将熟悉的服务与对发型的热爱带给更多顾客。',
    '在 GIP，我们相信好发型不只是外表好看，更是由内而外的自信。无论是简单修剪，还是一次全新的改变，我们都希望让你看起来更好，也感觉更好。',
  ],
};
